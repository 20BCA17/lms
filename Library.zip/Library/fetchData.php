<?php
//fetch.php;
if(isset($_POST["email"]))
{
 $connect = new PDO("mysql:host=localhost; dbname=library", "root", "");
//  $connect = new PDO("mysql:host=localhost; dbname=vlmscuma_localhost", "vlmscuma", "Nitin@123");
 $query = "
 SELECT * FROM tblstudents
 WHERE EmailId = '".trim($_POST["email"])."'
  union SELECT * FROM tblfaculties
  WHERE EmailId = '".trim($_POST["email"])."' ";
 $statement = $connect->prepare($query);
 $statement->execute();
 $total_row = $statement->rowCount();
 if($total_row == 0)
 {
  $output = array(
   'success' => true
  );
  echo json_encode($output);
 }
}
?>
