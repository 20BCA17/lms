<?php
session_start();
// error_reporting(0);
//  ob_start();

include "db.php";

?>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require('PHPMailer/Exception.php');
require('PHPMailer/SMTP.php');
require('PHPMailer/PHPMailer.php');
if (isset($_SESSION['EmailId'])) {

    if (isset($_POST['submit'])) {
        $FullName = $_POST['FullName'];
        $MobileNumber = $_POST['MobileNumber'];
        $EmailId = $_POST['EmailId'];
		$mail = new PHPMailer(true);

		
		try {
			
			$mail->isSMTP();                                         
			$mail->Host       = 'smtp.gmail.com';                    
			$mail->SMTPAuth   = true;                                   
			$mail->Username   = 'dubenitin445@gmail.com';                   
			$mail->Password   = 'ciruwmgrogqvedwc';                             
					
			$mail->Port       = 587;                                   
		
			$mail->setFrom('dubenitin445@gmail.com', 'vtcbcsr');
			$mail->addAddress($_POST["EmailId"]);   
		
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-y h:i:s');
			
			$q1 = mysqli_query($con, "SELECT * FROM tblstudents  WHERE EmailId='" . mysqli_real_escape_string($con, $_SESSION["EmailId"]) . "' union SELECT * FROM tblfaculties  WHERE EmailId='" . mysqli_real_escape_string($con, $_SESSION["EmailId"]) . "'");
        $q2 = mysqli_fetch_array($q1);
			
			$mail->isHTML(true);                                 
			$mail->Subject = 'Profile Update';
			$mail->Body    = "<h3 ><span style='color:green;'>Profile Update Successfully</span><br><br><table border=2 style='width: 500px;margin: auto; padding: 8px; margin-bottom: 10px;' >
            <thead>
                <tr>
                    <th>id</th>
                    <td>" .$q2['SfId'] ."</td>
                </tr>
                <tr>
                    <th>Reg Date</th>
                    <td>".$q2['RegDate']."</td>
                </tr>
                <tr>
                    <th>Last Updation Date</th>
                    <td>$date</td>
                </tr>
                <tr>
                    <th>Profile Status</th>
                    <td style='color:green;'>Active</td>
                </tr>
                <tr>
                    <th>Book Recived Date</th>
                    <td>".$_POST['FullName']."</td>
                </tr>
				<tr>
				<th>Name</th>
				<td>".$_POST['MobileNumber']."</td>
			</tr>
			<tr>
				<th>Email</th>
				<td>".$_POST['EmailId']."</td>
			</tr>

                
            </thead>
        </table>
        <br>
        <p>Profile has been update succesfully</p><br>
        <p>Thank you</p></h3>";
			
		   
		
		} catch (Exception $e) {
			echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
		}
		
		
        $s = mysqli_query($con, "UPDATE tblstudents  SET FullName='$FullName', MobileNumber='$MobileNumber',EmailId='$EmailId' WHERE EmailId='" . mysqli_real_escape_string($con, $_SESSION["EmailId"]) . "'");

        if ($s) {
			$mail->send();
            echo "<script type='text/javascript'>alert('Successful - Record Updated!'); window.location.href = 'logout.php';</script>";
        } else {
            echo "<script type='text/javascript'>alert('Unsuccessful - ERROR!'); window.location.href = 'change_profile.php';</script>";
        }
    }
}
$sql = "SELECT * FROM tblstudents WHERE EmailId='" . mysqli_real_escape_string($con, $_SESSION["EmailId"]) . "'";

$faculty = "SELECT * FROM tblfaculties WHERE EmailId='" . mysqli_real_escape_string($con, $_SESSION["EmailId"]) . "'";

$result = mysqli_query($con, $sql) or die("query failed");

$res2 = mysqli_query($con, $faculty) or die("query failed");

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {

        $_SESSION["EmailId"] = $row['EmailId'];
        $_SESSION["Password"] = $row['Password'];

        $query1 = mysqli_query($con, "SELECT * FROM tblstudents  WHERE EmailId='" . mysqli_real_escape_string($con, $_SESSION["EmailId"]) . "'");
        $query2 = mysqli_fetch_array($query1);
    }
} elseif (mysqli_num_rows($res2) > 0) {
    while ($row = mysqli_fetch_assoc($res2)) {
        $_SESSION["EmailId"] = $row['EmailId'];
        $_SESSION["Password"] = $row['Password'];
        $query1 = mysqli_query($con, "SELECT * FROM tblfaculties  WHERE EmailId='" . mysqli_real_escape_string($con, $_SESSION["EmailId"]) . "'");
        $query2 = mysqli_fetch_array($query1);
    }

	
}


?>
<html>

<head>
	
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<body>
<div class="limiter">

<div class="container-login100">
	<div class="wrap-login100">
		<form class="login100-form validate-form p-l-55 p-r-55 p-t-178" action="<?php $_SERVER['PHP_SELF'];?>" method="post" id="reg">
			<span class="login100-form-title">
			Change Profile
			</span>

			<div class="wrap-input100 validate-input m-b-16" >
			user id : <?php echo $query2['SfId']; ?>
			</div><br>
			<div class="wrap-input100 validate-input m-b-16" >
			Reg Date : <?php echo $query2['RegDate']; ?>
			</div><br>
			<div class="wrap-input100 validate-input m-b-16" >
			Last Updation Date : <?php echo $query2['UpdationDate']; ?>
			</div><br>
		
			<div class="wrap-input100 validate-input m-b-16" >
			Profile Status : <?php if($query2['Status']){
									echo "<span style='color:green;'>Active</span>";}else{
										echo "<span style='color:red;'>inactive</span>";
									} ?>
			</div><br>
		
			<div class="wrap-input100 validate-input m-b-30" >
				<input class="input100" type="text" id="EmailId" placeholder="EmailId" required  value="<?php echo $query2['FullName']; ?>" name="FullName">
				<span class="focus-input100"></span>
			</div>
			<div class="wrap-input100 validate-input m-b-30">
				<input class="input100" type="text" id="EmailId" placeholder="EmailId" required  value="<?php echo $query2['MobileNumber']; ?>" name="MobileNumber">
				<span class="focus-input100"></span>
			</div>
			<div class="wrap-input100 validate-input m-b-30" >
				<input class="input100" type="text" id="EmailId" placeholder="EmailId" required  value="<?php echo $query2['EmailId']; ?>" name="EmailId" readonly>
				<span class="focus-input100"></span>
			</div>
			<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="submit" type="submit">
						Update
						</button>
					</div>
			

					<div class="flex-col-c p-t-170 p-b-10">
						<span class="txt1 p-b-9">

						</span>

						
					</div>

			
		</form>
	</div>
	
</div>
</div>


	</div>


	</div>

</body>

</html>
