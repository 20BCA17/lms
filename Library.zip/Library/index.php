<?php
include 'db.php';
error_reporting(0);
$select = "SELECT * FROM `web_seting` ";
$run = mysqli_query($con, $select);
$row = mysqli_fetch_assoc($run);
$index_img = $row['index_img'];
$Description = $row['Description'];


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <style>
        body {
            height: 100%;
            margin: 0;
        }

        html {
            padding-bottom: 50px;
            min-height: 100%;
            box-sizing: border-box;
            -moz-box-sizing: border-box;
            position: relative;
        }


        #border {
            /* border: 5px solid black; */
            border-radius: 25px;
           
            background-color: #337ab7;
            color: white;
            font-size: 18px;
            font-family: 'Times New Roman', Times, serif;
            border-color: #29c3cc;
        }
        #bt{
            margin-bottom: 50px;
            
        }
        .footer {
  position:relative;
  left: 0;
  bottom: -63px;

  width: 100%;
  background-color: #f7f7f7;;
  color: black;
  text-align: center;
  font-weight: bold;
  font-size: 120%;
  border-top: 5px solid #337ab7;
  font-family:Bookman Old Style;
  padding: 25px 50px 25px 50px;
}
    </style>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vtcbcsr library</title>
    <link rel="icon" type="image/x-icon" href="https://www.vtcbcsr.edu.in/IMG/logo1.png">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<body>
<center>
    <div >
        <div class="col-md-8 ">
            <!-- <img src="https://elibrary.vtcbcsr.edu.in/assets/img/LMS.png" class="img-fluid" alt="Responsive image"> -->
            <img  src="admin/img/<?php echo $row['index_img']; ?>" class="img-fluid" width="100%" >
        </div>
    </div>
   
    <div class="">
        <div class="col-md-7 my-4 mb-2 p-3">
            <div class=" form-control" id="border">
                <h1 class="text-center">Welcome to VTCBCSR</h1>
                <br>
                <p class="text-capitalize">Vidhyabharti Trust is the name associated with education for more than three decades (Est. 1980) near Bardoli of Surat district and has now evolved as a symbol of quality education dedicated to nurture the talent and aspirations of the right youth of out nation.</p>
                <p class="text-capitalize">Vidhyabharti Trust College of Business, Computer-Science & Research is premier Institute under the Vidhyabharti Trust, Umrakh. To Impart quality education and traning to the terminal of technical education and allied research.</p>

            </div>
        </div>
    </div>
   
    


    <div class="col-md-5 my-4 " id="bt">
        <a href="login.php" class="btn form-control" style="background-color:#337ab7;color:white;">Login/Registration</a>
    </div>  

   
    </center>
    <div >

<p class="footer">VTCBCSR E-LIBRARY |Developed & Managed by : Ms.Mohini Patel & Ms.Rinkal Patel</p>
</div>
   
</body>

</html>