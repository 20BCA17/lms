<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/sidebar.php";
?>
<link href="css/multiselect.css" rel="stylesheet"/>
	<script src="js/multiselect.min.js"></script>
	<style>
		/* example of setting the width for multiselect */
		#testSelect1_multiSelect {
			width: 100px;
		}
	</style>

<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Manage Book
                    </h1>
                </div>
                
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <form action="Export/Book.php" method="post">
                                <a href="Add_Book.php" class="btn btn-info" style="color: white; text-decoration: none;">New Book</a>
                                
                                <span class="dropdown">
  <button class="btn dropdown btn-info" type="button" id="" data-toggle="dropdown" style="width: 200px;">

  Download Report
    <span class="caret"></span >
  </button>
  <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
  <input type="submit" value="Export" class="btn btn-success btn-sm" name="report" style="width: 200px;">
  
  <select id='testSelect1' multiple name="columns[]" required>
    <li><option value='id'>ID</option></li>
    <li><option value='BookName' >Book Name</option></li>
    <li><option value='CatId' >Category ID</option></li>
<li><option value='AuthorId'>Author ID</option></li>
<li><option value='ISBNNumber'>ISBN Number</option></li>
<li><option value='BookPrice'>Book Price</option></li>
<li><option value='BillNo'>Bill Number</option></li>
<li><option value='BillDate'>Bill Date</option></li>
<li><option value='Publisher'>Publisher</option></li>
    <li role="presentation" class="divider"></li>
</select>

  </ul>
</span>

                               
                                </form>
                             


                            </div>
                  
                            <script>
	document.multiselect('#testSelect1')
		.setCheckBoxClick("checkboxAll", function(target, args) {
			console.log("Checkbox 'Select All' was clicked and got value ", args.checked);
		})
		.setCheckBoxClick("1", function(target, args) {
			console.log("Checkbox for item with value '1' was clicked and got value ", args.checked);
		});


</script>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 ">
                                        <?php include '../db.php' ?>
                                        <?php $data = mysqli_query($con, "select * from tblbooks") ?>

                                        </script>
                                        <div class="table-responsive">
                                            <table id="dataTables-example" class="table table-striped table-bordered table-hover ">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>BookName</th>
                                                        <th>CatId</th>
                                                        <th>AuthorId</th>
                                                        <th>Accession Number</th>
                                                        <th>BookPrice</th>
                                                        <th>BillNo</th>
                                                        <th>BillDate</th>
                                                        <th>Publisher</th>
                                                        <th >Action </th>

                                                    </tr>
                                                </thead>


                                            </table>
                                        </div>
                                        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
                                        <script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.js" charset="utf8" type="text/javascript"></script>
                                        <script>
                                            $('#dataTables-example').on('click', 'td.editor-edit', function(e) {
                                                e.preventDefault();

                                                editor.edit($(this).closest('tr'), {
                                                    title: 'Edit record',
                                                    buttons: 'Update'
                                                });
                                            });
                                        </script>


                                        <script type="text/javascript">
                                            var i = 1;
                                            $(document).ready(function() {


                                                $('#dataTables-example').dataTable({

                                                    "processing": true,


                                                    "ajax": "BookFetch.php",
                                                    "columns": [{
                                                            "render": function(data, type, full, meta) {
        return i++;
      }
                                                        },
                                                        {
                                                            data: 'BookName'
                                                        },
                                                        {
                                                            data: 'CatId'
                                                        },
                                                        {
                                                            data: 'AuthorId'
                                                        },
                                                        {
                                                            data: 'ISBNNumber'
                                                        },
                                                        {
                                                            data: 'BookPrice'
                                                        },
                                                        {
                                                            data: 'BillNo'
                                                        },
                                                        {
                                                            data: 'BillDate'
                                                        },
                                                        {
                                                            data: 'Publisher'
                                                        },
                                                        {
                                                            data: null,
                                                            orderable: false,
                                                            className: 'text-center py-0 px-1',
                                                            render: function(data, type, row, meta) {
                                                                console.log(data)
                                                                return '<button class="btn btn-sm rounded-0 py-0 delete_data btn-danger" onclick="onDelete(' + data.ISBNNumber + ')">Delete</button><button class="btn btn-sm rounded-0 py-0 delete_data btn-primary" onclick="onEdit(' + data.ISBNNumber + ')">Edit</button>';
                                                            }
                                                        }



                                                    ]
                                                });
                                            });
                                        </script>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </div>


    </div>
</div>


<script>
    
    
    // function onDelete(ISBNNumber) {

    //     if (confirm("Are you sure you want to delete")) {

    //         $.ajax({
    //             url: "Delete_Book.php",
    //             type: "POST",
    //             cache: false,
    //             data: {
    //                 ISBNNumber: ISBNNumber

    //             },
    //             success: function(document) {
    //                 location.reload();

    //             }
    //         });
    //     }
    // }
    function onDelete(ISBNNumber) {
    var table = $('#dataTables-example').DataTable();
    var currentPage = table.page();

    if (confirm("Are you sure you want to delete?")) {
        $.ajax({
            url: "Delete_Book.php",
            type: "POST",
            cache: false,
            data: {
                ISBNNumber: ISBNNumber
            },
            success: function(response) {
                var row = table.row($('button[onclick="onDelete(' + ISBNNumber + ')"]').parents('tr'));
                row.remove().draw();
                table.page(currentPage).draw(false);
            },
            error: function(xhr, status, error) {
                alert("Error deleting book: " + error);
            }
        });
    }
}




    function onEdit(ISBNNumber) {

        $.ajax({
            url: "Update_Book.php",
            type: "POST",
            cache: false,
            data: {
                ISBNNumber: ISBNNumber

            },
            success: function() {
                window.location.href = 'Update_Book.php?ISBNNumber=' + ISBNNumber;

            }
        });
    }
</script>
<?php
include "include/script.php";
?>