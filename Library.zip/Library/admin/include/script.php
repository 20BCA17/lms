 <!-- jQuery Js -->
 <script src="assets/js/jquery-1.10.2.js"></script>
 <!-- Bootstrap Js -->
 <script src="assets/js/bootstrap.min.js"></script>
 <!-- Metis Menu Js -->
 <script src="assets/js/jquery.metisMenu.js"></script>
 
 <script src="assets/js/dataTables/jquery.dataTables.js"></script>
 <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
 <script>
   $(document).ready(function () {
     $('#dataTables-example').dataTable();
    });
    </script>
       
         <script src="assets/js/custom-scripts.js"></script>
         
         
         <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script> -->
         <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script> -->

    
    <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script> 
    
   
    
	<script src="js/multiselect.min.js"></script>
	<style>
		/* example of setting the width for multiselect */
		#testSelect1_multiSelect {
			width: 200px;
		}
	</style>