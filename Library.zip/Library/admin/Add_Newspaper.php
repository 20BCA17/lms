<?php
include "../auth.php";
include "include/header.php";
include "include/script.php";
include "include/sidebar.php";

?>






<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Add New Newspaper
                    </h1>
                </div>
                
                <div class="row">
                    <div class="col-md-8">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Newspaper Info
                            </div>
                            
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-md-12 ">
                                        <div class="form-group">
                                            <form  method="POST" action="<?php $_SERVER['PHP_SELF']; ?>" id="reg" autocomplete="off">

                                            <div class="col-md-12">
                                                <label for="">Newspaper Name</label>
                                                <input type="text" class="form-control" name="newspaper" required>
                                            </div>
                                            <br><br><br>
                                        <div class="col-md-12"><br>
                                            <input type="submit" class="btn btn-info" name="btnNewspaper" value="Save" />
                                        </div>
                                    </form>
                                        </div>

                                       
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php

include "../include/validation.php";
include "../include/validation_css.php";
?>
<?php
 include '../db.php';
 if (isset($_POST["btnNewspaper"])) {
        $newspaper=($_POST['newspaper']); 

        $query    = "INSERT into `tbladdnewspaper` (newspaper)
        VALUES ('$newspaper')";
                     
        $result   = mysqli_query($con, $query);
        if ($result) {
            echo "<script>alert('Newspaper inserted');</script>";?>
            <script>
                window.location.href='Manage_Add_News.php';
            </script>
        <?php } else {
            echo "<script>alert('Newspaper not inserted');</script>";
        }
    }
?>