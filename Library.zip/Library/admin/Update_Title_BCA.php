<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/script.php";
include "include/sidebar.php";
?>

<?php
 include '../db.php';
 $bca_title_id = $_GET['id'];
 $select = "SELECT * FROM `tbltitlebca` WHERE id=$bca_title_id";
$run = mysqli_query($con, $select);
$row = mysqli_fetch_assoc($run);
$bca_title_id = $_GET['id'];
$BookName = $row['BookName'];
$Author = $row['Author'];
$BookCopy = $row['BookCopy'];


?>

<script>
    if(window.history.replaceState){
        window.history.replaceState(null,null,window.location.href)
    }
</script>

<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Update BCA Title
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Title Info
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 ">
                                    <form action="" method="POST">
                                        <div class="form-group">
                                        

                                                <div class="col-md-4">
                                                    <label for="">Book Name</label>
                                                    <input type="text" class="form-control" name="BookName" value="<?php echo $BookName; ?>">
                                                </div>
                                               
                                                <div class="col-md-4 ">
                                                    <label for="">Author</label>
                                                    <input type="text" class="form-control" name="Author" value="<?php echo $Author; ?>">
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="">Book Copy</label>
                                                    <input type="text" name="BookCopy" id="" class="form-control" placeholder="Issue Number Must be unique" value="<?php echo $BookCopy; ?>">
                                                </div>
                                        </div>
                                        <br><br><br>
                                        <div class="col-md-12"><br>
                                        <button class="btn btn-info" name="btntitlebca" type="submit">Update</button>
                                        </div>
                                    </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php



if (isset($_POST["btntitlebca"])) {
    $update = "UPDATE `tbltitlebca` SET BookName='".$_POST['BookName']."',Author='".$_POST['Author']."',BookCopy='".$_POST['BookCopy']."' WHERE id=$bca_title_id";
    $run2 = mysqli_query($con, $update);
    if($run2){
        echo "<script>alert('Title Updated')
        window.location.href='Manage_Title_BCA.php';</script>"; ?>
    <?php }
    else{
        echo "<script>alert('Something went wrong. Please try again');</script>";
    }
    }
?>