<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/sidebar.php";
?>

<?php
include 'db.php';
if (isset($_POST["btnbookissue"])) {
    $AccessionNumber = $_POST['AccessionNumber'];
    $StudentId = $_POST['StudentId'];


    $query = "INSERT into `tblissuebookdetails` (AccessionNumber,StudentId)
        VALUES ('$AccessionNumber','$StudentId')";

    $result = mysqli_query($con, $query);
    if ($result) {
        echo "<script>alert('Book issued');</script>"; ?>

        <script>
            window.location.href = 'Manage_Issue_Book.php';
        </script>
<?php } else {
        echo "<script>alert('Book not issued');</script>";
    }
}

?>

<?php
$data = mysqli_query($con, "SELECT * FROM tblstudents");
?>
<head>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
</head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
<script type="text/javascript" src="script.js"></script>


<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Issue a New Book
                    </h1>
                </div>
                <div class="row">
                    <div class="col-md-8">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Issue a New Book
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-md-12 ">
                                        <div class="form-group">
                                            <form action="" method="POST">


                                                <div class="col-md-12">
                                                    <label for="">User ID</label>
                                                    <input type="text" class="form-control" name="StudentId" id="studentname">
                                                    <br>
                                                    <span id="name"></span>
                                                </div>
                                                <div class="col-md-12"><br>
                                                    <label for="">Accession Number</label><br>
                                                    <input type="text" class="form-control" name="AccessionNumber">
                                                </div>
                                                <?php foreach ($data as $value) { ?>
                                                    <tr>


                                                        <td><?php echo $value['FullName']; ?></td>


                                                    </tr>

                                                <?php } ?>
                                                <div class="col-md-12"><br>
                                                    <button class="btn btn-info" name="btnbookissue" type="submit">Issue Book</button>
                                                </div>
                                            </form>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php
include "include/script.php";
?>