<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/script.php";
include "include/sidebar.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- <title>Document</title> -->

</head>

<body>
    <div id="wrapper">
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header" style="color: gray;">
                            ADMIN DASHBOARD
                        </h1>
                    </div>
                    <?php

                    include '../db.php';


                    $sql = ("SELECT * FROM tblbooks");

                    if ($result = mysqli_query($con, $sql)) {

                        $rowcount = mysqli_num_rows($result);

                        //   printf(" %d\n", );
                    }

                    // Close the connection
                    mysqli_close($con);

                    ?>


                    <div class="row">
                        <div class="col-md-3 col-sm-12 col-xs-12">
                            <div class="panel panel-primary text-center no-boder bg-color-green">
                                <div class="panel-left pull-left red">
                                    <i class="fa fa-book fa-5x"></i>

                                </div>
                                <div class="panel-right pull-right">
                                    <h3><?php echo $rowcount  ?></h3>
                                    <strong><a href="Manage_Book.php">Book Listed</a></strong>

                                </div>
                            </div>
                        </div>
                        <?php

                        include '../db.php';


                        $sql = ("SELECT * FROM tblissuebookdetails");

                        if ($result = mysqli_query($con, $sql)) {

                            $rowcount = mysqli_num_rows($result);

                            //   printf(" %d\n", );
                        }

                        // Close the connection
                        mysqli_close($con);

                        ?>
                        <div class="col-md-3 col-sm-12 col-xs-12">
                            <div class="panel panel-primary text-center no-boder bg-color-blue">
                                <div class="panel-left pull-left blue">
                                    <i class="fa fa-bars fa-5x "></i>



                                </div>
                                <div class="panel-right pull-right">
                                    <h3><?php echo $rowcount  ?></h3>
                                    <strong><a href="Manage_Issue_Book.php">Faculty Book Issued</a></strong>
                                 

                                </div>
                            </div>
                        </div>
                        <?php

include '../db.php';


$sql = ("SELECT * FROM tblissuebookstudents");

if ($result = mysqli_query($con, $sql)) {

    $rowcount = mysqli_num_rows($result);

    //   printf(" %d\n", );
}

// Close the connection
mysqli_close($con);

?>
<div class="col-md-3 col-sm-12 col-xs-12">
    <div class="panel panel-primary text-center no-boder bg-color-blue">
        <div class="panel-left pull-left blue">
            <i class="fa fa-bars fa-5x "></i>
            



        </div>
        <div class="panel-right pull-right">
            <h3><?php echo $rowcount  ?></h3>
        
            <strong><a href="Manage_Issue_Book_Student.php">Student Book Issued</a></strong>

        </div>
    </div>
</div>
                        <?php

                        include '../db.php';


                        $sql = (" SELECT * FROM tblfaculties");

                        if ($result = mysqli_query($con, $sql)) {

                            $rowcount = mysqli_num_rows($result);

                            //   printf(" %d\n", );
                        }

                        // Close the connection
                        mysqli_close($con);

                        ?>
                        <div class="col-md-3 col-sm-12 col-xs-12">
                            <div class="panel panel-primary text-center no-boder bg-color-red">
                                <div class="panel-left pull-left red">
                                    <i class="fa fa-users fa-5x "></i>



                                </div>
                                <div class="panel-right pull-right">
                                    <h3><?php echo $rowcount  ?></h3>
                                    <strong>
                                        <a href="faculty.php">Faculty List</a><br>
                                

                                </div>
                            </div>
                        </div>
                        <?php

                        include '../db.php';


                        $sql = ("SELECT * FROM tblstudents ");

                        if ($result = mysqli_query($con, $sql)) {

                            $rowcount = mysqli_num_rows($result);

                            //   printf(" %d\n", );
                        }

                        // Close the connection
                        mysqli_close($con);

                        ?>
                        <div class="col-md-3 col-sm-12 col-xs-12">
                            <div class="panel panel-primary text-center no-boder bg-color-red">
                                <div class="panel-left pull-left green">
                                    <i class="fa fa-users fa-5x "></i>



                                </div>
                                <div class="panel-right pull-right">
                                    <h3><?php echo $rowcount  ?></h3>
                                    <strong>
                                        
                                        <a href="student.php">Student List</a></strong>

                                </div>
                            </div>
                        </div>
                        
                        <?php

                        include '../db.php';


                        $sql = ("SELECT * FROM tbltitlebca");

                        if ($result = mysqli_query($con, $sql)) {

                            $rowcount = mysqli_num_rows($result);

                            //   printf(" %d\n", );
                        }

                        // Close the connection
                        mysqli_close($con);

                        ?>
                        <div class="col-md-3 col-sm-12 col-xs-12">
                            <div class="panel panel-primary text-center no-boder bg-color-blue">
                                <div class="panel-left pull-left blue">
                                    <i class="fa fa-list fa-5x "></i>
                                    <!-- <i class="fa fa-heading fa-5x"></i> -->


                                </div>
                                <div class="panel-right pull-right">
                                    <h3><?php echo $rowcount  ?></h3>
                                    <strong>
                                        <a href="Manage_Title_BCA.php">BCA Title List</a>

                                </div>
                            </div>
                        </div>
                        <?php
                        include '../db.php';
                        $sql = ("SELECT * FROM tbltitlebba");

                        if ($result = mysqli_query($con, $sql)) {

                            $rowcount = mysqli_num_rows($result);

                            //   printf(" %d\n", );
                        }

                        // Close the connection
                        mysqli_close($con);

                        ?>
                        <div class="col-md-3 col-sm-12 col-xs-12">
                            <div class="panel panel-primary text-center no-boder bg-color-green">
                                <div class="panel-left pull-left blue">
                                    <i class="fa fa-List fa-5x "></i>



                                </div>
                                <div class="panel-right pull-right">
                                    <h3><?php echo $rowcount  ?></h3>
                                    <strong>
                                        <a href="Manage_Title_BBA.php">BBA Title List</a>

                                </div>
                            </div>
                        </div>
                        <?php

                        include '../db.php';


                        $sql = ("SELECT * FROM tblauthors");

                        if ($result = mysqli_query($con, $sql)) {

                            $rowcount = mysqli_num_rows($result);

                            //   printf(" %d\n", );
                        }

                        // Close the connection
                        mysqli_close($con);

                        ?>
                        <div class="col-md-3 col-sm-12 col-xs-12">
                            <div class="panel panel-primary text-center no-boder bg-color-green">
                                <div class="panel-left pull-left green">
                                    <i class="fa fa-users fa-5x "></i>



                                </div>
                                <div class="panel-right pull-right">
                                    <h3><?php echo $rowcount  ?></h3>
                                    <strong>
                                        <a href="Manage_Authors.php">Authors</a></strong>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
</body>

</html>