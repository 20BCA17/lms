<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<style>

    .pad{
       padding: 5px;
    }
</style>
<?php 
include '../db.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require('../PHPMailer/Exception.php');
require('../PHPMailer/SMTP.php');
require('../PHPMailer/PHPMailer.php');
$num=1;
$select = "SELECT DISTINCT SfId  FROM tblissuebookstudents where ReturnStatus IS Null ";
$run = mysqli_query($con, $select);
while ($row = mysqli_fetch_assoc($run)) {
   //  $id = $row['id'];
    $SfId = $row['SfId'];

    $stdName = "SELECT * FROM `tblstudents` WHERE SfId='$SfId'";
    $run2 = mysqli_query($con, $stdName);
    while($row2 = mysqli_fetch_assoc($run2)){
        $EmailId = $row2['EmailId'];
      
    }  
    // echo '<br> '.$num.' '.$SfId.' '.$EmailId.' </br>';
    
    $num++;
    

if (isset($_POST["reg"])) {
    $bookreturn = $_POST['bookreturn'];
    $newDate = date("d-m-Y", strtotime($bookreturn));
    
    $mail = new PHPMailer(true);

    try {
                
        $mail->isSMTP();                                           
        $mail->Host       = 'smtp.gmail.com';                    
        $mail->SMTPAuth   = true;                                  
        $mail->Username   = 'dubenitin445@gmail.com';                   
        $mail->Password   = 'ciruwmgrogqvedwc';                             
       
        $mail->Port       = 587;                        
    
        //Recipients
        $mail->setFrom('dubenitin445@gmail.com', 'To Nitin');
        $mail->addAddress("$EmailId");     //Add a recipient
      
    
        $mail->isHTML(true);                                  
        $mail->Subject = 'VTCBCSR Library Registration';
        $mail->Body    = "Please Return Book $newDate";
        // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
    echo " <script>
    window.location.href = 'Manage_Issue_Book_Student.php';
</script>";
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
    
         
    
        }
    }


?>
<?php
include "../auth.php";
include "include/header.php";
include "include/sidebar.php";
?>
<link href="css/multiselect.css" rel="stylesheet"/>
	<script src="js/multiselect.min.js"></script>
	<style>
		/* example of setting the width for multiselect */
		#testSelect1_multiSelect {
			width: 100px;
		}
	</style>

<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Manage Student Book
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                      <form action="Export/Issue_book_Student.php" method="post">
                         <a class="btn btn-info" href="issue-book.php" style="color: white; text-decoration: none;">New Book</a>
                         <a class="btn btn-info" href="Mul_books_return.php" style="color: white; text-decoration: none;">Multipule Books Return</a>
                         <span class="dropdown">
  <button class="btn dropdown btn-info" type="button" id="" data-toggle="dropdown" style="width: 200px;">

  Download Report
    <span class="caret"></span >
  </button>
  <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
  <input type="submit" value="Export" class="btn btn-success btn-sm" name="report" style="width: 200px;">
  
  <select id='testSelect1' multiple name="columns[]" required>
    <li><option value='id'>ID</option></li>
    <li><option value='BookId' >Book Id</option></li>
    <li><option value='SfId' >Student Id</option></li>
<li><option value='IssuesDate'>Issue Date</option></li>
<li><option value='ReturnDate'>Return Date</option></li>
<li><option value='ReturnStatus'>Return Status</option></li>
<li><option value='fine'>Fine</option></li>

    <li role="presentation" class="divider"></li>
</select>

  </ul>
</span>
                            <button class="btn btn-info" type="button" data-toggle="modal" data-target="#myModal">Send Mail

</button>
</form>
                            </div>  
                            <script>
	document.multiselect('#testSelect1')
		.setCheckBoxClick("checkboxAll", function(target, args) {
			console.log("Checkbox 'Select All' was clicked and got value ", args.checked);
		})
		.setCheckBoxClick("1", function(target, args) {
			console.log("Checkbox for item with value '1' was clicked and got value ", args.checked);
		});


</script>
                           
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <form action="" method="post">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Book Return Notice</h4>
            </div>
            <div class="modal-body">
             <label for="return date">Book Return Date</label>
            <input type="date" class="form-control" name="bookreturn" min="<?php echo date('Y-m-d'); ?>">
            

            </div>
            <div class="modal-footer">
            <button type="submit" name="reg" class="btn btn-primary">Send</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
        </form>
    </div>
</div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 ">
                                        
                                        <?php require "../db.php"; ?>
                                    <div class="dt">
                                        <div class="table-responsive">
                                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                                <thead>
                                                <tr>
                                            
                                                <th>No</th>
                                                <th>Student Id</th>
                                                <th>User Name</th>
                                                <th>Book Name</th>
                                                <th>Accession Number</th>
                                                <th>Issued Date</th>
                                                <th>Return Date</th>
                                                <th>Action</th>
                                            </tr>
                                            <tbody>
                                            <tr>
                                            <?php
                                            // include "../db.php";
                                            $num=1;
                                            $select = "SELECT * FROM tblissuebookstudents";
                                            $run = mysqli_query($con, $select);
                                            while ($row = mysqli_fetch_assoc($run)) {
                                                $id = $row['id'];
                                                $SfId = $row['SfId'];
                                                $BookId = $row['BookId'];
                                                $BookId = $row['BookId'];
                                                $IssuesDate = $row['IssuesDate'];
                                                $ReturnDate = $row['ReturnDate'];
                                                $ReturnStatus = $row['ReturnStatus'];
                                            ?>
                                            
                                               
                                                
                                                <td><?php echo $num; ?></td>
                                                <td ><?php echo $SfId; ?></td>
                                                <td ><?php $stdName = "SELECT * FROM `tblstudents` WHERE SfId='$SfId'";
                                                $run2 = mysqli_query($con, $stdName);
                                                while($row2 = mysqli_fetch_assoc($run2)){
                                                    $FullName = $row2['FullName'];
                                                    echo $FullName;
                                                } ?></td>
                                                <td><?php $Bookname = "SELECT * FROM `tblissuebookstore` WHERE BookId='$BookId'";
                                                                    $run3 = mysqli_query($con, $Bookname);
                                                                    while ($row3 = mysqli_fetch_assoc($run3)) {
                                                                        $BookName = $row3['BookName'];
                                                                        echo $BookName;
                                                                    } ?></td>
                                                <td><?php echo $BookId ?></td>
                                                <td><?php echo $IssuesDate ?></td>
                                                <td><?php
                                                if($ReturnStatus = $row['ReturnStatus']==""){
                                                    echo "<span style='color:red;'>Not Return Yet</span>";
                                                } 
                                         
                                                else{
                                                    echo $ReturnDate;
                                                }?></td>
                                                 <td> <a class="btn btn-primary btn-sm pad"  href="Issue_book_student_up.php?id=<?php echo $id; ?>"><i class="fa fa-edit fa-fw" ></i>Edit</a> 
                                              <a class="btn btn-danger btn-sm pad"  onclick="return confirm('Are You Sure')" href="delete_issue_student.php?id=<?php echo $id; ?>">  <i class="fa fa-trash fa-fw"></i>Delete</button></td>
                                                </tr>
                                                <?php $num++;} ?>
                                            </tbody>
                                            </table>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php
include "include/script.php";
?>