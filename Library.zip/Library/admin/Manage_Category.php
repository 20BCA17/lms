<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/script.php";
include "include/sidebar.php";
?>
<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header" >
                        Manage Categories
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <a href="Add_Category.php" class="btn btn-info">Add Category</a>
                                <a href="Export/Category.php" class="btn btn-info">Download Report</a>
                        
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 ">
                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Category</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                            $num=1;
                                            include "../db.php";
                                            $select = "SELECT * FROM tblcategory";
                                            $run = mysqli_query($con, $select);
                                            while ($row = mysqli_fetch_assoc($run)) {
                                                $id = $row['id'];
                                                $CategoryName = $row['CategoryName'];
                                                $Status = $row['Status'];
                                            ?>
                                              
                                                    <tr>
                                                        <td><?php echo $num ?></td>
                                                        <td><?php echo $CategoryName ?></td>
                                                        <td><?php
                                                            if($Status === "active"){?>
                                                                <button class="btn btn-success">Active</button>
                                                            <?php  }
                                                            else{?>
                                                                <button class="btn btn-danger">Inactive</button>
                                                            <?php  }
                                                        ?>
                                                        </td>
                                                        <!-- <td><button class="btn btn-success">Active</button></td> -->
                                                        <td> <a class="btn btn-info btn-sm"  style="text-decoration: none; color:white;" href="Update_Category.php?id=<?php echo $id; ?>"><i class="fa fa-edit fa-fw" ></i>Edit</a>
                                                       <a class="btn btn-danger btn-sm" onclick="return confirm('Are You Sure')"style="text-decoration: none; color:white;" href="Delete_Category.php?id=<?php echo $id; ?>"><i class="fa fa-trash fa-fw"></i>Delete</button>
                                                        </td>
                                                    </tr>
                                               
                                            <?php $num++;} ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

