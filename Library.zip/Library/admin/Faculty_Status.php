<?php
include_once '../db.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require('../PHPMailer/Exception.php');
require('../PHPMailer/SMTP.php');
require('../PHPMailer/PHPMailer.php');
$SfId =$_GET['SfId'];
$Status = $_GET['Status'];
$stdName = "SELECT * FROM `tblfaculties` WHERE SfId='$SfId'";
$run2 = mysqli_query($con, $stdName);
while ($row2 = mysqli_fetch_assoc($run2)) {
    $FullName = $row2['FullName'];
    $EmailId = $row2['EmailId'];
}

$mail = new PHPMailer(true);

		

try {
    //Server settings
    // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'dubenitin445@gmail.com';                     //SMTP username
    $mail->Password   = 'ciruwmgrogqvedwc';                               //SMTP password
             //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('dubenitin445@gmail.com', 'vtcbcsr');
    $mail->addAddress("$EmailId");     //Add a recipient
  

	date_default_timezone_set('Asia/Kolkata');
	$date = date('d-m-y h:i:s');
	if($_GET['Status']==1){
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Account Status';
        $mail->Body    = "<h2 style='color:green;'>your account has been activated</h2><br>
        <p>hello $FullName your account hass been successfully activated. </p>
        <br> activated time : $date";
    }
	
   
  else{
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Account Status';
    $mail->Body    = "<h2 style='color:red;'>your account has been blocked</h2><br>
    <p>hello $FullName your account hass been blocked.please contact in library </p>
    <br> Blocked time : $date";
  }

   
    



$done = "UPDATE tblfaculties set Status='$Status' WHERE SfId='$SfId'";
// echo $update; die;
mysqli_query($con,$done);
$mail->send();
header('location:Faculty.php');
} catch (Exception $e) {
  echo "Message could not be sent. Mailer Error";
  header('location:Faculty.php');
}
?>