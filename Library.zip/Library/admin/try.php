<form action="download.php" method="post">
    <input type="checkbox" name="columns[]" value="id"> ID<br>
    <input type="checkbox" name="columns[]" value="BookName"> Book Name<br>
    <input type="checkbox" name="columns[]" value="CatId"> Category ID<br>
    <input type="checkbox" name="columns[]" value="AuthorId"> Author ID<br>
    <input type="checkbox" name="columns[]" value="ISBNNumber"> ISBN Number<br>
    <input type="checkbox" name="columns[]" value="BookPrice"> Book Price<br>
    <input type="checkbox" name="columns[]" value="BillNo"> Bill Number<br>
    <input type="checkbox" name="columns[]" value="BillDate"> Bill Date<br>
    <input type="checkbox" name="columns[]" value="Publisher"> Publisher<br>
    <input type="submit" value="Download">
</form>
