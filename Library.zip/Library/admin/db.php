
<?Php
// $host_name = "localhost";
// $database = "vlmscuma_localhost"; // Change your database nae
// $username = "vlmscuma";          // Your database user id 
// $password = "Nitin@123";          // Your password


$host_name = "localhost";
$database = "library"; // Change your database nae
$username = "root";          // Your database user id 
$password = "";   
//////// Don't Edit below /////////
try {
$dbh = new PDO('mysql:host='.$host_name.';dbname='.$database, $username, $password);
} catch (PDOException $e) {
print "Error!: " . $e->getMessage() . "<br/>";
echo "<br><br><font color=red>Check MySQL login details inside <b>config.php</b> file</font>";
die();
}


// $host_name = "localhost";
// $database = "vlmscuma_localhost"; // Change your database nae
// $username = "vlmscuma";          // Your database user id 
// $password = "Nitin@123";          // Your password


// $host_name = "sql110.byetcluster.com";
// $database = "epiz_34027242_vlms"; // Change your database nae
// $username = "epiz_34027242";          // Your database user id 
// $password = "bhC8bPFI6wyA3";   
// //////// Don't Edit below /////////a
// try {
// $dbh = new PDO('mysql:host='.$host_name.';dbname='.$database, $username, $password);
// } catch (PDOException $e) {
// print "Error!: " . $e->getMessage() . "<br/>";
// echo "<br><br><font color=red>Check MySQL login details inside <b>config.php</b> file</font>";
// die();
// }
?>
