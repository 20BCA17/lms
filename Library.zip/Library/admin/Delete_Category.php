<?php
	include('../db.php');
	if(isset($_GET['id']))
	{
		$id = $_GET['id'];
		$delete = "delete from `tblcategory` where id=$id";
		$res = mysqli_query($con,$delete);
		if($res)
		{
			echo "<script>alert('category Deleted');</script>";?>
        <script>
            window.location.href='Manage_Category.php';
        </script>
		<?php }
		else
		{
            echo "<script>alert('category Does not Deleted');</script>";
		}
	}
?>