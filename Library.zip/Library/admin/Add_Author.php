<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/script.php";
include "include/sidebar.php";
?>



<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Add Author
                    </h1>
                </div>
                <div class="row">
                    <div class="col-md-10">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Author Info
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-md-12 ">
                                        <form method="POST" id="reg" autocomplete="off">
                                        <div class="form-group">

                                            <div class="col-md-12">
                                                <label for="">Author Name</label>
                                                <input type="text" class="form-control" name="AuthorName" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12"><br>
                                        <input type="submit" class="btn btn-info" name="btnAuthor" value="Save" />
                                        </div>
                                        <br><br><br>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php

include "../include/validation.php";
include "../include/validation_css.php";
?>



<?php
 include '../db.php';
 if (isset($_POST["btnAuthor"])) {
        $AuthorName=($_POST['AuthorName']); 
        

        $query    = "INSERT into `tblauthors` (AuthorName)
        VALUES ('$AuthorName')";
                     
        $result   = mysqli_query($con, $query);
        
        if ($result) {
            echo "<script>alert('category inserted');</script>";
            ?>
            <script>
                window.location.href='Manage_Authors.php';
            </script>
        <?php } else {
            echo "<script>alert('category not inserted');</script>";
        }
    }
?>