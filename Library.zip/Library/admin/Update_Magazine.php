<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/script.php";
include "include/sidebar.php";
?>

<?php
 include '../db.php';
 $Magazine_id = $_GET['id'];
 $select = "SELECT * FROM `tblmagazine` WHERE id=$Magazine_id";
$run = mysqli_query($con, $select);
$row = mysqli_fetch_assoc($run);
$Magazine_id = $_GET['id'];
$MagazineName = $row['MagazineName'];
$IssueNo = $row['IssueNo'];
$PublicationDate = $row['PublicationDate'];
$IssueDate = $row['IssueDate'];
$Price = $row['Price'];



?>

<script>
    if(window.history.replaceState){
        window.history.replaceState(null,null,window.location.href)
    }
</script>



<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Update Magazine
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               Update Magazine Info
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 ">
                                    <form action="" method="POST">
                                        <div class="form-group">
                                        

                                                <div class="col-md-4">
                                                    <label for="">Magazine Name</label>
                                                    <input type="text" class="form-control" name="MagazineName" value="<?php echo $MagazineName; ?>">
                                                </div>
                                                <div class="col-md-4 ">
                                                    <label for="">Issue No</label>
                                                    <input type="text" class="form-control" name="IssueNo" value="<?php echo $IssueNo; ?>">
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="">Publication Date</label>
                                                    <input type="Date" name="PublicationDate" id="" class="form-control" value="<?php echo $PublicationDate; ?>">
                                                </div>
                                        </div>
                                        <br><br><br>
                                        <div class="form-group">


                                            <div class="col-md-4">
                                                <label for="">Issue Date</label>
                                                <input type="Date" name="IssueDate" id="" class="form-control" value="<?php echo $IssueDate; ?>">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="">Price</label>
                                                <input type="text" name="Price" id="" class="form-control" value="<?php echo $Price; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-12"><br>
                                        <button class="btn btn-info" name="btnmagazine" type="submit">Update</button>
                                        </div>
                                    </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php


if (isset($_POST["btnmagazine"])) {
    $update = "UPDATE `tblmagazine` SET MagazineName='".$_POST['MagazineName']."',IssueNo='".$_POST['IssueNo']."',PublicationDate='".$_POST['PublicationDate']."',IssueDate='".$_POST['IssueDate']."',Price='".$_POST['Price']."' WHERE id=$Magazine_id";
    $run2 = mysqli_query($con, $update);
    if($run2){
        echo "<script>alert('Magazine Updated');</script>";?>
        <script>
            window.location.href='Manage_Magazine.php';
        </script>
    <?php }
    else{
        echo "<script>alert('Magazine Not Updated');</script>";
    }
    }
?>
