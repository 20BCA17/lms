<?php
include "../auth.php";
include "include/header.php";
include "include/sidebar.php";
?>


<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Manage Book
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <a href="Add_Book.php" class="btn btn-info" style="color: white; text-decoration: none;">New Book</a>
                                <a href="Export/Book.php" class="btn btn-info">Download Report</a>

                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 ">
                                        <?php include '../db.php' ?>
                                        <?php $data = mysqli_query($con, "select * from tblbooks") ?>

                                        </script>
                                        <div class="table-responsive">
                                            <table id="dataTables-example" class="table table-striped table-bordered table-hover ">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>BookName</th>
                                                        <th>CatId</th>
                                                        <th>AuthorId</th>
                                                        <th>ISBNNumber</th>
                                                        <th>BookPrice</th>
                                                        <th>BillNo</th>
                                                        <th>BillDate</th>
                                                        <th>Publisher</th>
                                                        <th>Action</th>

                                                    </tr>
                                                </thead>


                                            </table>
                                        </div>
                                        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
                                        <script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.js" charset="utf8" type="text/javascript"></script>
                                        <script>
                                            $('#dataTables-example').on('click', 'td.editor-edit', function(e) {
                                                e.preventDefault();

                                                editor.edit($(this).closest('tr'), {
                                                    title: 'Edit record',
                                                    buttons: 'Update'
                                                });
                                            });



                                            // Delete a record
                                            $('#dataTables-example').on('click', 'td.editor-delete', function(e) {
                                                e.preventDefault();

                                                editor.remove($(this).closest('tr'), {
                                                    title: 'Delete record',
                                                    message: 'Are you sure you wish to remove this record?',
                                                    buttons: 'Delete'
                                                });
                                            });
                                        </script>
                                        <script type="text/javascript">
                                            $(document).ready(function() {
                                                $('#dataTables-example').dataTable({
                                                    "processing": true,
                                                    "ajax": "BookFetch.php",
                                                    "columns": [{
                                                            data: 'id'
                                                        },
                                                        {
                                                            data: 'BookName'
                                                        },
                                                        {
                                                            data: 'CatId'
                                                        },
                                                        {
                                                            data: 'AuthorId'
                                                        },
                                                        {
                                                            data: 'ISBNNumber'
                                                        },
                                                        {
                                                            data: 'BookPrice'
                                                        },
                                                        {
                                                            data: 'BillNo'
                                                        },
                                                        {
                                                            data: 'BillDate'
                                                        },
                                                        {
                                                            data: 'Publisher'
                                                        },



                                                    ]

                                                });
                                            });
                                            var deleteData = function(id) {
                                                $.ajax({
                                                    type: "GET",
                                                    url: "Delete_Book.php",
                                                    data: {
                                                        deleteId: id
                                                    },
                                                    dataType: "html",
                                                    success: function(data) {
                                                        $('#msg').html(data);
                                                        $('#dataTables-example').load('BookFetch.php');


                                                    }

                                                });
                                            };
                                        </script>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php
include "include/script.php";
?>