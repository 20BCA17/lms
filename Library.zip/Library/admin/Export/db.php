<?php
error_reporting(0);
$con = new mysqli('localhost','root','','library');
// $con = new mysqli('localhost','vlmscuma','Nitin@123','vlmscuma_localhost');
// $con = new mysqli('localhost','lmscis','Nitin@123','lmscis_library');

if(!$con){
    die("Error on the connectioin ". $con ->connect_error);
}
?>