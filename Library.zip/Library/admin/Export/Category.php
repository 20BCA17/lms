<?php 
// Load the database configuration file 
error_reporting(0);
include_once '../../db.php'; 
 
// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 
 
// Excel file name for download 
$fileName = "Category" . date('Y-m-d') . ".xls"; 
 
// Column names 
$fields = array('id', 'CategoryName','Status','CreationDate'); 
 
// Display column names as first row 
$excelData = '<table style="border-collapse: collapse; border: 1px solid black;">'; 
$excelData .= '<tr>';
foreach ($fields as $field) {
    $excelData .= '<th style="border: 1px solid black; padding: 5px;">' . $field . '</th>';
}
$excelData .= '</tr>';
 
// Fetch records from database 
$query = mysqli_query($con,"SELECT * FROM tblcategory ORDER BY id ASC"); 
if($query->num_rows > 0){ 
    // Output each row of the data 
    while($row = $query->fetch_assoc()){ 
    
        $lineData = array($row['id'], $row['CategoryName'], $row['Status'], $row['CreationDate']); 
        array_walk($lineData, 'filterData'); 
        $excelData .= '<tr>';
        foreach ($lineData as $data) {
            $excelData .= '<td style="border: 1px solid black; padding: 5px;">' . $data . '</td>';
        }
        $excelData .= '</tr>';
    } 
}else{ 
    $excelData .= '<tr><td colspan="4">No records found...</td></tr>'; 
}
$excelData .= '</table>';
 
// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;
?>