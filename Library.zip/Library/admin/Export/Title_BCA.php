<?php 
// Load the database configuration file 
error_reporting(0);
include_once '../../db.php';  
 
// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 
 
// Excel file name for download 
$fileName = "BCA_Title" . date('Y-m-d') . ".xls"; 
 
// Column names 
$fields = array('id', 'BookName','Author','BookCopy'); 

// HTML table header for borders
$excelData = "<table border='1'><tr><th>" . implode("</th><th>", $fields) . "</th></tr>";
 
// Fetch records from database 
$query = mysqli_query($con,"SELECT * FROM tbltitlebca ORDER BY id ASC"); 
if($query->num_rows > 0){ 
    // Output each row of the data 
    while($row = $query->fetch_assoc()){ 
        $lineData = array($row['id'], $row['BookName'], $row['Author'], $row['BookCopy']); 
        array_walk($lineData, 'filterData'); 
        $excelData .= "<tr><td>" . implode("</td><td>", array_values($lineData)) . "</td></tr>"; 
    } 
}else{ 
    $excelData .= "<tr><td colspan='" . count($fields) . "'>No records found...</td></tr>"; 
} 

// HTML table footer
$excelData .= "</table>";
 
// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;
