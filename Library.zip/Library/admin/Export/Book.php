<?php
// Load the database configuration file
error_reporting(0);
include_once '../../db.php'; 

// Filter the excel data
function filterData(&$str){
    $str = preg_replace("/\t/", "\\t", $str);
    $str = preg_replace("/\r?\n/", "\\n", $str);
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
}

// Excel file name for download
$fileName = "Book" . date('Y-m-d') . ".xls";

// Default column names
$defaultFields = array('id', 'BookName', 'CatId', 'AuthorId', 'ISBNNumber', 'BookPrice', 'BillNo', 'BillDate', 'Publisher');

// Retrieve selected columns from the form
$selectedFields = isset($_POST['columns']) ? $_POST['columns'] : $defaultFields;

// Filter selected columns
$selectedFields = array_intersect($defaultFields, $selectedFields);

// Display selected column names as first row
$excelData = '<table border="1"><tr><td>' . implode('</td><td>', array_values($selectedFields)) . '</td></tr>';

// Fetch records from database with selected columns
$query = mysqli_query($con, "SELECT " . implode(',', $selectedFields) . " FROM tblbooks ORDER BY id ASC");
if($query->num_rows > 0){
    // Output each row of the data
    while($row = $query->fetch_assoc()){

        $lineData = array_values($row);
        array_walk($lineData, 'filterData');
        $excelData .= '<tr><td>' . implode('</td><td>', array_values($lineData)) . '</td></tr>';
    }
}else{
    $excelData .= '<tr><td colspan="' . count($selectedFields) . '">No records found...</td></tr>';
}

$excelData .= '</table>';

// Headers for download
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"$fileName\"");

// Render excel data
echo $excelData;

exit;
?>
