<?php
// db settings
include '../db.php';
// fetch records
// $sql = "select id, BookName, email from customers";
$sql = "select  BookName, CatId, AuthorId, ISBNNumber, BookPrice, BillNo, BillDate, Publisher from tblbooks";
$result = mysqli_query($con, $sql);

while($row = mysqli_fetch_assoc($result)) {
    $array[] = $row;
}

$dataset = array(
    "echo" => 1,
    "totalrecords" => count($array),
    "totaldisplayrecords" => count($array),
    "data" => $array
);

echo json_encode($dataset);
?>