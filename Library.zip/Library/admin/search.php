<?php
// Check if the ID is submitted
if(isset($_GET['SfId'])) {
  // Get the selected ID from the form
  $selectedId = $_GET['SfId'];

include '../db.php';


 
  // Prepare the SQL query
  $sql = "SELECT * FROM tblissuebookstudents"; 
  $result = $con->query($sql);

  // Check if the query returned any rows
  if ($result->num_rows > 0) {
    // Fetch the data from the result set
    $row = $result->fetch_assoc();
    $selectedData = $row['SfId'];  
    $selectedData = $row[''];  

    echo " $selectedId: $selectedData";
  } else {
    echo "No data found for ID $selectedId";
  }

  // Close the database connection
  $con->close();
}
?>
