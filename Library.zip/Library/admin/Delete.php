<?php
	include('../db.php');
	if(isset($_GET['id']))
	{
		$id = $_GET['id'];
		$delete = "delete from `tblauthors` where id=$id";
		$res = mysqli_query($con,$delete);
		if($res)
		{
			echo "<script>alert('Author Deleted');</script>";?>
        <script>
            window.location.href='Manage_Authors.php';
        </script>
		<?php }
		else
		{
            echo "<script>alert('Journal Does not Deleted');</script>";
		}
	}
    $con 
?>