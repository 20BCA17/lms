<?php
include "../auth.php";
include "include/header.php";
include "include/script.php";
include "include/sidebar.php";
?>

<?php
 include '../db.php';
 $ISBNNumber = $_GET['ISBNNumber'];
 $select = "SELECT * FROM `tblbooks` WHERE ISBNNumber=$ISBNNumber";
$run = mysqli_query($con, $select);
$row = mysqli_fetch_assoc($run);
// $ISBNNumber = $_GET['ISBNNumber'];

$BookName = $row['BookName'];
$CatId = $row['CatId'];
$AuthorId = $row['AuthorId'];
$ISBNNumber = $row['ISBNNumber'];
$BookPrice = $row['BookPrice'];
$BillNo = $row['BillNo'];
$BillDate = $row['BillDate'];
$Publisher = $row['Publisher'];


 
?>

<script>
    if(window.history.replaceState){
        window.history.replaceState(null,null,window.location.href)
    }
</script>

<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Update Book
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Update Book Info
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 ">
                                    <form action="" method="POST">
                                        <div class="form-group">
                                        

                                                <div class="col-md-4">
                                                    <label for="">Book Name</label>
                                                    
                                                    <input type="text" class="form-control" name="BookName" value="<?php echo $BookName; ?>">
                                                </div>
                                               
                                                <div class="col-md-4 ">
                                                    <label for="">Category</label>
                                                   <?php
                                                   include 'db.php';
                                                   $data = mysqli_query($con, "select * from tblcategory");
                                                   echo "<select name='CatId' class='selectpicker form-control' data-show-subtext='true' data-live-search='true' >name</option>";
                                                   echo "<option value='$row[CatId]' readonly>$row[CatId]</option>";
                                                   foreach($data as $value){
                                                       
                                                        
                                                       echo "<option value='$value[CategoryName]' >$value[CategoryName]</option>";
                                                   }
                                                   echo "</select>";
                                                   
                                                   ?>
                                                   
                                                </div>
                                                <div class="col-md-4 ">
                                                    <label for="">Author</label>
                                                
                                                        <?php
                                                        require "../db.php";
                                                        $data = mysqli_query($con, "SELECT * FROM tblauthors");

                                                        echo "<select class='selectpicker form-control' data-show-subtext='true' data-live-search='true' name='AuthorId'>";

                                                        echo "<option  value='$row[AuthorId]'   readonly>$row[AuthorId]</option>";
                                                        foreach ($data as $value) {
                                                            
                                                            echo "<option  value='$value[AuthorName]' >$value[AuthorName]</option>";
                                                        }

                                                        echo "</select>";
                                                        ?>

                                                      
                                                    </div>
                                        </div>
                                        <br><br><br>    

                                        <div class="form-group">


                                            <div class="col-md-4">
                                                <label for="">Accession Number</label>
                                                <input type="text" name="ISBNNumber"  class="form-control" value="<?php echo $ISBNNumber; ?>" >
                                            </div>
                                            <div class="col-md-4">
                                                <label for="">Price</label>
                                                <input type="text" name="BookPrice" id="" class="form-control" value="<?php echo $BookPrice; ?>">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="">Bill Number</label>
                                                <input type="text" name="BillNo" id="" class="form-control" value="<?php echo $BillNo; ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-md-4">
                                                <label for="">Bill Date</label>
                                                <input type="date" name="BillDate" id="" class="form-control" value="<?php echo $BillDate; ?>">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="">Publisher</label>
                                                <input type="text" name="Publisher" id="" class="form-control" value="<?php echo $Publisher; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-12"><br>
                                        <button class="btn btn-info" name="btnbook" type="submit">Update</button>
                                        </div>
                                    </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php


if (isset($_POST["btnbook"])) {
    // $CategoryName = $POST['CategoryName'];
    // $Status = $POST['Status'];
    $update = "UPDATE `tblbooks` SET  BookName='".$_POST['BookName']."',CatId='".$_POST['CatId']."',AuthorId='".$_POST['AuthorId']."',ISBNNumber='".$_POST['ISBNNumber']."',BookPrice='".$_POST['BookPrice']."',BillNo='".$_POST['BillNo']."',BillDate='".$_POST['BillDate']."',Publisher='".$_POST['Publisher']."' WHERE ISBNNumber=$ISBNNumber";
    $run2 = mysqli_query($con, $update);
    if($run2){
        echo "<script>alert('Book Updated');</script>";?>
        <script>
            window.location.href='Manage_Book.php';
        </script>
    <?php }
    else{
        echo "<script>alert('Book Not Updated');</script>";
    }
    }
?>