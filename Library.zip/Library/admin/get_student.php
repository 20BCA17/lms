
<?php 

require_once("db.php");
if(!empty($_POST["SfId"])) {
  $SfId= strtoupper($_POST["SfId"]);
 
    $sql ="SELECT FullName,Status FROM tblstudents  WHERE SfId=:SfId union SELECT FullName,Status FROM   tblfaculties WHERE SfId=:SfId";
$query= $dbh -> prepare($sql);
$query-> bindParam(':SfId', $SfId, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query -> rowCount() > 0)
{
foreach ($results as $result) {
if($result->Status==0)
{
echo "<span style='color:red'>  ID Blocked </span>"."<br />";
echo "<b>Name-</b>" .$result->FullName;
 echo "<script>$('#submit').prop('disabled',true);</script>";
} else {
?>


<?php  
echo htmlentities($result->FullName);
 echo "<script>$('#submit').prop('disabled',false);</script>";
}
}
}
 else{
  
  echo "<span style='color:red'> Invaid Student Id. Please Enter Valid Student id .</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
}
}



?>
