<form method="GET" action="search.php">
  <input type="text" name="SfId" placeholder="Enter ID">
  <input type="submit" value="Search">
</form>
