<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/sidebar.php";
?>


<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Manage Add Newspaper
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <a class="btn btn-info" href="Add_Newspaper.php" style="color: white; text-decoration: none;">Add NewsPaper</a>
                            </div>  
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 table-responsive">
                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Newspaper</th>
                                              
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            
                                            <?php
                                            $num=1;
                                            include "../db.php";
                                            $select = "SELECT * FROM tbladdnewspaper";
                                            $run = mysqli_query($con, $select);
                                            while ($row = mysqli_fetch_assoc($run)) {
                                                $id = $row['id'];
                                                $newspaper = $row['newspaper'];
                                           
                                            ?>
                                           <tr>
                                                <td><?php echo $num ?></td>
                                                <td><?php echo $newspaper ?></td>
                                              
                                                <td><a class="btn btn-danger" onclick="return confirm('Are You Sure')" style="text-decoration: none; color:white;" href="Delete_news.php?id=<?php echo $id; ?>"><i class="fa fa-trash fa-fw"></i>Delete</button>
                                                        </td>
                                                        </tr>
                                            <?php $num++;} ?>
                                           
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php
include "include/script.php";
?>