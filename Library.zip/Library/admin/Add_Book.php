<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
}

?>

<?php
include "../auth.php";
include 'include/header.php';
include "include/script.php";
include "include/sidebar.php";
?>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add Author</h4>
            </div>
            <div class="modal-body">
                <form method="post">
                    <div class="col-md-12">
                        <label for="">Author Name</label>
                        <input type="text" class="form-control" name="AuthorName">
                    </div>

                    <div class="col-md-12"><br>
                        <input type="submit" class="btn btn-info" name="Author" value="Save" />
                    </div>
                </form>

                <?php
                include '../db.php';
                if (isset($_POST["Author"])) {
                    $AuthorName = ($_POST['AuthorName']);


                    $query    = "INSERT into `tblauthors` (AuthorName)
        VALUES ('$AuthorName')";

                    $result   = mysqli_query($con, $query);
                    if ($result) {
                ?>
                        <script>
                            window.location.href = 'Add_Book.php';
                        </script>
                <?php } else {
                    }
                }
                mysqli_close($con);
                ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>




<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Add Book
                    </h1>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Book Info
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 ">

                                        <form action="" method="POST" autocomplete="off" id="reg">

                                            <!-- <div class="form-group"> -->
                                            <div class="form-group row">

                                                <div class="col-md-4">
                                                    <label for="">Book Name</label>

                                                    <input type="text" class="form-control" name="BookName" required>
                                                </div>
                                                <div class="col-md-4 ">
                                                    <label for="">Category</label>
                                                    <select class="form-control" name="CatId">
                                                        <?php
                                                        include "../db.php";
                                                        $sql = "SELECT * FROM `tblcategory`";
                                                        $all_categories = mysqli_query($con, $sql);
                                                        ?>
                                                        <?php
                                                        while ($category = mysqli_fetch_array($all_categories, MYSQLI_ASSOC)) {
                                                        ?>
                                                            <option value="<?php echo $category['CategoryName']; ?>"><?php echo $category["CategoryName"]; ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>

                                                <div class="col-md-4">

                                                    <label for="">Author</label>
                                                    <div class=" input-group ">
                                                        <?php
                                                        require "../db.php";
                                                        $data = mysqli_query($con, "SELECT * FROM tblauthors");

                                                        echo "<select class='selectpicker form-control' data-show-subtext='true' data-live-search='true' name='AuthorId' >";

                                                        foreach ($data as $value) {


                                                            echo "<option  value='$value[AuthorName] ' >$value[AuthorName] </option>";
                                                        }

                                                        echo "</select>";
                                                        ?>

                                                        <span class="input-group-btn">
                                                            <button class="btn btn-primary" type="button" data-toggle="modal" data-target="#myModal">Add

                                                            </button>
                                                        </span>
                                                    </div>



                                                </div>

                                            </div>
                                            <?php


                                            // $select = "SELECT * FROM `tblbooks`";
                                            $select = "SELECT * FROM tblbooks WHERE ISBNNumber = (SELECT MAX(ISBNNumber) FROM tblbooks)";
                                            $run = mysqli_query($con, $select);
                                            $row1 = mysqli_fetch_assoc($run);
                                            $ISBNNumber = $row1['ISBNNumber'];
                                            // $Description = $row['Description'];


                                            ?>
                                      





                                            <div class="form-group row">
                                                <div class="col-md-4">
                                                    <label for="">Accession Number</label>
                                                    <input type="hidden" id="textbox1" onchange="passValue()" value="<?php echo $row1['ISBNNumber'] +1 . ','; ?>">
                                       <input type="text" id="textbox3" onchange="passValue()" class="form-control">
                                                    <input type="hidden" required class="form-control" placeholder="Accession Must be unique" name="ISBNNumber" value="<?php echo $row1['ISBNNumber'] +1 . ','; ?>" id="textbox2">
                                                    <span class="help-block" style="font-size: small;">ISBN Must be unique</span>
                                                </div>
                                                <script>
  function passValue() {
    var textbox1Value = document.getElementById('textbox1').value;
    var textbox3Value = document.getElementById('textbox3').value-1;
    document.getElementById('textbox2').value = textbox1Value + textbox3Value;
  }
</script>
                                                <div class="col-md-4">
                                                    <label for="">Price</label>
                                                    <input type="text" id="" class="form-control" name="BookPrice" required>

                                                </div>
                                                <div class="col-md-4">
                                                    <label for="">Bill Number</label>
                                                    <input type="text" id="" class="form-control" name="BillNo" required>
                                                </div>
                                            </div>
                                            <!-- <br><br><br><br> -->
                                            <div class="form-group row">

                                                <div class="col-md-4">
                                                    <label for=""> Bill Date</label>
                                                    <input type="date" id="" class="form-control" name="BillDate">
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="">Publisher</label>
                                                    <input type="text" id="" class="form-control" name="Publisher">
                                                </div>

                                            </div>

                                            <div class="col-md-12"><br>
                                                <!-- <input type="submit" name="btnbook" id=""> -->
                                                <button class="btn btn-info" name="btnbook" type="submit">Save</button>
                                            </div>


                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div> <?php


        include "../include/validation.php";
        include "../include/validation_css.php";

        ?>


<?php
include '../db.php';
if (isset($_POST["btnbook"])) {

    $BookName = $_POST['BookName'];
    $CatId = $_POST['CatId'];
    $AuthorId = $_POST['AuthorId'];
    $ISBNNumber = $_POST['ISBNNumber'];

    $BookPrice = $_POST['BookPrice'];
    $BillNo = $_POST['BillNo'];
    $BillDate = $_POST['BillDate'];
    $Publisher = $_POST['Publisher'];
    $sql_u = "SELECT * FROM tblbooks WHERE ISBNNumber='$ISBNNumber'";
    $res_u = mysqli_query($con, $sql_u);
    if (mysqli_num_rows($res_u) > 0) {
        echo "<script>alert('ISBNNumber ($ISBNNumber) Is Already  Booked');
            window.location.href='Add_Book.php';</script>";
    } else {

        $num_arr = explode(",", $ISBNNumber);
        $num1 = trim($num_arr[0]);
        $num2 = trim($num_arr[1]);
        $sum =  $num1 + $num2;
        for ($i = $num1; $i <= $sum; $i++) {

            $query = "INSERT into `tblbooks` (BookName,CatId,AuthorId,ISBNNumber,BookPrice,BillNo,BillDate,Publisher)
    VALUES ('$BookName','$CatId','$AuthorId','$i','$BookPrice','$BillNo','$BillDate','$Publisher')";

            $result = mysqli_query($con, $query);
            if ($result) {
                echo "<script>alert('Book inserted');
            window.location.href='Manage_Book.php';</script>"; ?>


<?php } else {
                echo "<script>alert('Book not inserted');</script>";
            }
        }
    }
}
?>