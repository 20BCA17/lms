<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/sidebar.php";
?>



<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Add Magazine
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Magazine Info
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 ">
                                    <form action="" method="POST" id="reg">
                                    <div class="form-group row">
                                        

                                                <div class="col-md-4">
                                                    <label for="">Magazine Name</label>
                                                    <input type="text" class="form-control" name="MagazineName" required>
                                                </div>
                                                <div class="col-md-4 ">
                                                    <label for="">Issue No</label>
                                                    <input type="text" class="form-control" name="IssueNo" required>
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="">Publication Date</label>
                                                    <input type="Date" name="PublicationDate" id="" class="form-control">
                                                </div>
                                        </div>
                                        
                                        <div class="form-group row">


                                            <div class="col-md-4">
                                                <label for="">Issue Date</label>
                                                <input type="Date" name="IssueDate" id="" class="form-control">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="">Price</label>
                                                <input type="text" name="Price" id="" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12"><br>
                                        <button class="btn btn-info" name="btnmagazine" type="submit">Save</button>
                                        </div>
                                    </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>



<?php
include '../db.php';
if (isset($_POST["btnmagazine"])) {
    $MagazineName = ($_POST['MagazineName']);
    $IssueNo = ($_POST['IssueNo']);
    $PublicationDate = ($_POST['PublicationDate']);
    $IssueDate = ($_POST['IssueDate']);
    $Price = ($_POST['Price']);

    $query = "INSERT INTO `tblmagazine` (MagazineName,IssueNo,PublicationDate,IssueDate,Price) VALUES ('$MagazineName','$IssueNo','$PublicationDate','$IssueDate','$Price')";

    $result = mysqli_query($con, $query);
    if ($result) {
        echo "<script>alert('Magazine inserted');</script>"; ?>

        <script>

                window.location.href='Manage_Magazine.php';
        </script>
<?php } else {
        echo "<script>alert('Magazine not inserted');</script>";
    }
}
?>

<?php
include "include/script.php";
include "../include/validation.php";
include "../include/validation_css.php";
?>