<?php
	include('../db.php');
	if(isset($_GET['id']))
	{
		$id = $_GET['id'];
		$delete = "delete from `tbltitlebca` where id=$id";
		$res = mysqli_query($con,$delete);
		if($res)
		{
			echo "<script>alert('Title Deleted');</script>";?>
        <script>
            window.location.href='Manage_Title_BCA.php';
        </script>
		<?php }
		else
		{
            echo "<script>alert('Title Does not Deleted');</script>";
		}
	}
?>