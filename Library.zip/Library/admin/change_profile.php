<?php
session_start();

include "../db.php";

?>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require('../PHPMailer/Exception.php');
require('../PHPMailer/SMTP.php');
require('../PHPMailer/PHPMailer.php');

if (isset($_SESSION['EmailId'])) {

    if (isset($_POST['submit'])) {
        $FullName = $_POST['FullName'];
        $UserName = $_POST['UserName'];
        $EmailId = $_POST['EmailId'];

		$mail = new PHPMailer(true);

		try {
                             
			$mail->isSMTP();                                           
			$mail->Host       = 'smtp.gmail.com';                   
			$mail->SMTPAuth   = true;                                  
			$mail->Username   = 'dubenitin445@gmail.com';                    
			$mail->Password   = 'ciruwmgrogqvedwc';                              
		   
			$mail->Port       = 587;                                   
	
		   
			$mail->setFrom('dubenitin445@gmail.com', 'vtcbcsr');
			$mail->addAddress("$EmailId");     
	
	
			
		} catch (Exception $e) {
			echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
		}

        $s = mysqli_query($con, "UPDATE admin  SET FullName='$FullName', UserName='$UserName',EmailId='$EmailId' WHERE EmailId='" . mysqli_real_escape_string($con, $_SESSION["EmailId"]) . "'");

        if ($s) {
			$mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'Change Profile';
            $mail->Body    = "<h3 style='color:green';>Successfully Change your profile</h3><br>
            <table border=2 style='width: 500px;margin: auto; padding: 8px; margin-bottom: 10px;' >
            <thead>
                
                <tr>
                    <th>Name</th>
                    <td>$FullName</td>
                </tr>
                <tr>
                    <th>Accession Number</th>
                    <td>$UserName</td>
                </tr>
                <tr>
                    <th>BookName </th>
                    <td>$EmailId</td>
                </tr>
               
                
            </thead>
        </table>
        <br>
        
        <p>Thank you</p>";
            $mail->send();
            echo "<script type='text/javascript'>alert('Successful - Record Updated!'); window.location.href = 'logout.php';</script>";
        } else {
            echo "<script type='text/javascript'>alert('Unsuccessful - ERROR!'); window.location.href = 'change_profile.php';</script>";
        }
    }
}
$query1 = mysqli_query($con, "SELECT * FROM admin WHERE EmailId='" . mysqli_real_escape_string($con, $_SESSION["EmailId"]) . "'");
$query2 = mysqli_fetch_array($query1);
// $row = mysqli_fetch_array($result);
?>





<html>

<head>
	
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<body>


<div class="limiter">

<div class="container-login100">
	<div class="wrap-login100">
		<form class="login100-form validate-form p-l-55 p-r-55 p-t-178" action="<?php $_SERVER['PHP_SELF'];?>" method="post" id="reg">
			<span class="login100-form-title">
			Change Profile
			</span>

			<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
				<input class="input100" type="text" id="EmailId" name="FullName" placeholder="FullName" required value="<?php echo $query2['FullName']; ?>" >
				<span class="focus-input100"></span>
			</div>
			<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
				<input class="input100" type="text" id="EmailId" name="UserName" placeholder="UserName" required value="<?php echo $query2['UserName']; ?>" >
				<span class="focus-input100"></span>
			</div>
			<div class="wrap-input100 validate-input m-b-30" data-validate="Please enter username">
				<input class="input100" type="text" id="EmailId" name="EmailId" placeholder="EmailId" required value="<?php echo $query2['EmailId']; ?>" >
				<span class="focus-input100"></span>
			</div>
			<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="submit" type="submit">
						Update
						</button>
					</div>
			

					<div class="flex-col-c p-t-170 p-b-40">
						<span class="txt1 p-b-9">

						</span>

						
					</div>

			
		</form>
	</div>
</div>
</div>

	</div>


	</div>

</body>

</html>
