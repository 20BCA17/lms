<?php
session_start();
error_reporting(0);
include "../include/icon.php";
?>




<!DOCTYPE html>
<html lang="en">

<head>
	<title>Login V8</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->
</head>

<body>


	<div class="limiter">

		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form p-l-55 p-r-55 p-t-178" method="POST" id="reg">
					<span class="login100-form-title">
						Sign In
					</span>

					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100" type="text" id="EmailId" name="EmailId" placeholder="Email Id" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Please enter password">
						<input class="input100" type="password" id="Password" name="Password" placeholder="Password" required>
						<span class="focus-input100"></span>
					</div>

					<br>

					<div class="container-login100-form-btn flex-col-c p-t-170 p-b-40">
						<button class="login100-form-btn" name="submit" type="submit">
							Sign in
						</button>
					</div>

					<div class="flex-col-c p-t-170 p-b-40">
						<span class="txt1 p-b-9">
							Back to home
						</span>

						<a href="../home.php" class="txt3">
							Click here
						</a>
						<?php

						include '../db.php';


						$sql = ("SELECT * FROM admin");


						if ($result = mysqli_query($con, $sql)) {

							$rowcount = mysqli_num_rows($result);
						}


						mysqli_close($con);

						?>
						<?php
						if ($rowcount == null) {
							echo '<a href="Student_reg.php" class="txt3"> Admin Sign Up </a>';
						}


						?>
					</div>
				</form>
			</div>
		</div>
	</div>




</body>

</html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.8.0/parsley.js"></script>

<?php
include "../include/validation.php";
include "../include/validation_css.php";
?>

<?php
include '../db.php';
if (isset($_POST["submit"])) {
	$_SESSION['last_time'] = time();


	$EmailId = mysqli_real_escape_string($con, $_POST['EmailId']);

	$Password = mysqli_real_escape_string($con, $_POST['Password']);
	$Password = md5($Password);

	
	$adm = "SELECT * FROM admin WHERE EmailId = '{$EmailId}' AND Password = '{$Password}'";


	
	$res = mysqli_query($con, $adm) or die("query failed");


 if (mysqli_num_rows($res) > 0)
		while ($row = mysqli_fetch_assoc($res)) {
			$_SESSION["EmailId"] = $row['EmailId'];
			$_SESSION["Password"] = $row['Password'];
			header("Location: home.php");
		}
	
	else {


		echo "<script>alert('EmailId or Password Not Matched ')
                    window.location.href = 'login.php';
                  </script>";
	}
}

?>