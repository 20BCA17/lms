
<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>  

<?php

						include '../db.php';


						$sql = ("SELECT * FROM admin");


						if ($result = mysqli_query($con, $sql)) {

							$rowcount = mysqli_num_rows($result);
						}


						mysqli_close($con);

						?>
						<?php
						if ($rowcount == null) {
							// echo '<a href="admin/AdminRegistration.php" class="txt3"> Admin Sign Up </a>';
                        
						?>
<?php

include "../include/icon.php";

include "../include/validation_css.php";

?>

<?php

    include '../db.php';
    if (isset($_POST["reg"])) {
        $FullName    = stripslashes($_REQUEST['FullName']);
        $FullName    = mysqli_real_escape_string($con, $FullName);

        $EmailId = stripslashes($_REQUEST['EmailId']);
        $EmailId = mysqli_real_escape_string($con, $EmailId);

        $UserName = stripslashes($_REQUEST['UserName']);
        $UserName = mysqli_real_escape_string($con, $UserName);

        $Password = stripslashes($_REQUEST['Password']);
        $Password = mysqli_real_escape_string($con, $Password);
        
	
        // if(!preg_match ("/^[0-9]*$/",$SfId)==$SfId){
            $query    = "INSERT into `admin` (FullName, EmailId, UserName , Password)
            VALUES ('$FullName','$EmailId', '$UserName', '" . md5($Password) . "')";
       
       
             
        $result   = mysqli_query($con, $query);
        if ($result) {
            echo "<script>alert('Admin Registration Successfully')
            window.location.href = '../login.php';
          </script>";
            // header("Location:../login.php");
        } else {
            echo "failed";
        }

    }
    

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login V8</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form p-l-55 p-r-55 p-t-178" method="POST" id="reg">
					<span class="login100-form-title">
						 Sign Up
					</span>

				
					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100" type="text" name="FullName" placeholder="SURNAME FRISTNAME LASTNAME" required>

						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100" type="text"  name="EmailId" id="email_address"  required placeholder="Enter Email ID" data-parsley-type="email" data-parsley-trigger="focusout" data-parsley-checkemail data-parsley-checkemail-message="Email Address already Exists" >
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100 input_text" type="text" name="UserName" required placeholder="Username">
						<span class="focus-input100"></span>
					</div>
				

					<div class="wrap-input100 validate-input m-b-16" data-validate = "Please enter password">
						<input class="input100" type="password" name="Password" id="password" placeholder="Password" required data-parsley-length="[4, 6]" data-parsley-trigger="keyup">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-50" data-validate = "Please enter password">
						<input class="input100" type="password" id="confirm_password" placeholder="Confirm Password" data-parsley-equalto="#password" data-parsley-trigger="keyup" required class="form-control">
						<span class="focus-input100"></span>
					</div>
					
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" type="submit" name="reg">
						Register
						</button>
					</div>

					<div class="flex-col-c p-t-170 p-b-40">
						<span class="txt1 p-b-9">

						</span>

						
					</div>
				</form>
			</div>
		</div>
	</div>
	



</body>
</html>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.8.0/parsley.js"></script>

    <?php
include "../include/validation.php";
include "../include/validation.php";

?>
<?php } 

else{
    echo "<script>alert('Admin already exists')
    window.location.href = 'logout.php';
  </script>";
}?>




