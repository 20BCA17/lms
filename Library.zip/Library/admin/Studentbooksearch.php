<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/sidebar.php";
?>

<html>
<head>

</head>
<body >
<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Manage Book
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <a class="btn btn-info" href="issue-book.php" style="color: white; text-decoration: none;">New Book</a>
                                <a href="Export/Issue_book_Student.php" class="btn btn-info">Download Report</a>
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 ">

                                        <?php
                                        include '../db.php';
                                        // process search query
                                        if (isset($_POST['submit'])) {
                                            // get search term from form
                                            $search_term = $_POST['search'];

                                            // construct SQL query
                                            $query = "SELECT * FROM tblissuebookstudents WHERE SfId LIKE '%" . mysqli_real_escape_string($con, $search_term) . "%'";

                                            // execute query
                                            $result = mysqli_query($con, $query);
                                        }
                                        ?>
                                        <form method="POST" id="reg">
                                            <div class="  input-group col-md-5">

                                                <input type="text" name="search" placeholder="Enter search student id" class="form-control" >
                                                <span class="input-group-btn">
                                                    <input type="submit" name="submit" value="Search" class="btn btn-info ">
                                                </span>
                                            </div>
                                        </form>



                                        <?php
                                        // display search results
                                        if (isset($result)) {
                                            $num = 1;
                                            if (mysqli_num_rows($result) > 0) {
                                                echo '<table class="table table-striped table-bordered table-hover">';
                                                echo '<tr><th>Sr</th><th>Student Name </th><th>Book Name</th></th><th>Accession Number </th><th>IssuesDate </th><th>ReturnDate </th></th><th>Action </th></tr>';
                                                while ($row = mysqli_fetch_array($result)) {
                                                    $id = $row['id'];
                                                    $SfId = $row['SfId'];
                                                    $BookId = $row['BookId'];
                                                    echo '<tr>';
                                                    echo '<td>' . $num . '</td>';
                                        ?>
                                                    <?php $stdName = "SELECT * FROM `tblstudents` WHERE SfId='$SfId'";
                                                    $run2 = mysqli_query($con, $stdName);
                                                    while ($row2 = mysqli_fetch_assoc($run2)) {
                                                        $FullName = $row2['FullName'];

                                                        echo '<td>' . $row2['FullName'] . '</td>';
                                                    } ?>

                                                    <?php $Bookname = "SELECT * FROM `tblbooks` WHERE ISBNNumber='$BookId'";
                                                    $run3 = mysqli_query($con, $Bookname);
                                                    while ($row3 = mysqli_fetch_assoc($run3)) {
                                                        $BookName = $row3['BookName'];

                                                        echo '<td>' . $row3['BookName'] . '</td>';
                                                    } ?>


                                        <?php








                                                    echo '<td>' . $row['BookId'] . '</td>';
                                                    echo '<td>' . $row['IssuesDate'] . '</td>';
                                                    if ($row['ReturnStatus'] >= 0) {

                                                        echo '<td>'
                                                            . $row['ReturnDate'] . '</td>';
                                                    } else {
                                                        echo '<td style="color:red";> Not Return  </td>';
                                                    }
                                                    echo '<td>' . "<a href='Issue_book_student_up.php?id=$id' class='btn btn-primary btn-sm'><i class='fa fa-edit fa-fw' ></i>Edit</a>  <a 
			onclick=\"return confirm('Are you sure?')\" href='delete_issue_student.php?id=$id' class='btn btn-danger btn-sm' ><i class='fa fa-trash fa-fw'></i> Delete</a> " . '</td>';

                                                    echo '</tr>';
                                                    $num++;
                                                }
                                                echo '</table>';
                                            } else {
                                                echo 'No results found.';
                                            }
                                        }

                                        ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>



                </div>

            </div>
        </div>

</body>



</html>

        <?php


        include "../include/validation.php";
        include "../include/validation_css.php";

        ?>