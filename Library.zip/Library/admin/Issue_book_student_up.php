<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/script.php";
include "include/sidebar.php";
?>

<?php
 include '../db.php';
 $id = $_GET['id'];
 $select = "SELECT * FROM `tblissuebookstudents` WHERE id=$id";
$run = mysqli_query($con, $select);
$row = mysqli_fetch_assoc($run);

?>


<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Update Student Issued Book
                    </h1>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading ">
                             Student Issued Book Details
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-md-12 ">
                                        <form action="" method="post"  id="reg">
                                            <div class="form-group">
                                                <strong>User Name</strong> :
                                                <?php
                                               
                                                $stdName = "SELECT f.*,b.*,ib.* FROM tblissuebookstudents as ib LEFT join tblstudents as f on ib.SfId=f.SfId LEFT join tblbooks as b on b.ISBNNumber=ib.BookId where ib.id=$id";
                                                $run2 = mysqli_query($con, $stdName);
                                                while($row2 = mysqli_fetch_assoc($run2)){
                                                    $FullName = $row2['FullName'];
                                                    $EmailId = $row2['EmailId'];
                                                    $BookName = $row2['BookName'];
                                                    echo $FullName; 
                                                }
                                                
                                                ?>
                                            </div>
                                            <div class="form-group">
                                                <strong>Book Name</strong> :
                                                <?php  echo $BookName;?>
                                                
                                            </div>
                                            <div class="form-group">
                                                <strong>Accession Number</strong> : <?php echo $row['BookId']; ?>
                                            </div>
                                            <div class="form-group">
                                                <strong>Book Issued Date</strong> : <?php echo $row['IssuesDate']; ?>
                                            </div>
                                            <div class="form-group">
                                                <strong>Book Returned Date</strong> : <?php
                                                 if($ReturnStatus = $row['ReturnStatus']==""){
                                                    echo "<span style='color:red;'>Not Return </span>";
                                                } 
                                             
                                                else{
                                                    echo $row['ReturnDate'];
                                                }
                                                ?>
                                            </div>
                                            <div>
                                                <select name="" id="" class="form-control"></select>
                                            </div>
                                            <div class="form-group">
                                                <strong> <label for="">Penalty</label> </strong>: 
                                                <input type="text" name="ReturnStatus" id="" class="form-control" value="<?php echo $row['ReturnStatus']; ?>" >
                                            </div>
                                            <div class="form-group">
                                                <button class="btn btn-primary" name="update" type="submit">Return Book</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>
<?php

include "../include/validation.php";
include "../include/validation_css.php";
?>



<?php
include '../db.php';
$id = $_GET['id'];
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require('../PHPMailer/Exception.php');
require('../PHPMailer/SMTP.php');
require('../PHPMailer/PHPMailer.php');
$ReturnStatus = $row['ReturnStatus'];



 if (isset($_POST["update"])) {
    
    $mail = new PHPMailer(true);

		

    try {
        
        $mail->isSMTP();                                         
        $mail->Host       = 'smtp.gmail.com';                   
        $mail->SMTPAuth   = true;                                   
        $mail->Username   = 'dubenitin445@gmail.com';                    
        $mail->Password   = 'ciruwmgrogqvedwc';                               
                
        $mail->Port       = 587;                                    
    
        //Recipients
        $mail->setFrom('dubenitin445@gmail.com', 'vtcbcsr');
        $mail->addAddress("$EmailId");     //Add a recipient
      
        // currunt data 
        date_default_timezone_set('Asia/Kolkata');
        $date = date('Y-m-d h:i:s');
  
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Book Returned';
        $mail->Body    = "<h3 style='color:green';>Book Returned Successfully </h3><br>
        <table border=2 style='width: 500px;margin: auto; padding: 8px; margin-bottom: 10px;' >
        <thead>
            <tr>
                <th>id</th>
                <td>".$row['SfId']."</td>
            </tr>
            <tr>
                <th>Name</th>
                <td>$FullName</td>
            </tr>   
            <tr>
                <th>BookName</th>
                <td>$BookName</td>
            </tr>
            <tr>
                <th>Accession Number</th>
                <td>".$row['BookId']."</td>
            </tr>
            <tr>
                <th>Book Issued Date</th>
                <td>".$row['IssuesDate']."</td>
            </tr>
            <tr>
            <th>Book Returned Date</th>
            <td>$date</td>
        </tr>
            
        </thead>
    </table>
    <br>
    
    <h4>Thank you...</h4>";
   
       
       
        $mail->send();  
        echo 'Message has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
    $update = "UPDATE `tblissuebookstudents` SET ReturnStatus='".$_POST['ReturnStatus']."' WHERE id=$id";
    $run2 = mysqli_query($con, $update);
    if($run2){
      
        echo "<script>alert('Book Returned');
        window.location.href='Manage_Issue_Book_Student.php';</script>";?>
       
    <?php }
    else{
        echo "<script>alert('Not Updated');</script>";
    }
    }
    ?>
