
<?php 
require_once("db.php");
if(!empty($_POST["bookid"])) {
  $book_id = explode(",",$_POST["bookid"]);
	foreach($book_id as $bookid){
  $sql2 ="SELECT * FROM tblissuebookdetails WHERE (BookId=:bookid) union SELECT * FROM tblissuebookstudents  WHERE (BookId=:bookid)";
  $query2= $dbh -> prepare($sql2);
  $query2-> bindParam(':bookid', $bookid, PDO::PARAM_STR);
  
  $query2-> execute();
  
  $results2 = $query2 -> fetchAll(PDO::FETCH_OBJ);
}
echo "<script>alert('".$sql12."');</script>";
 if($query2 -> rowCount() > 0)
{
	echo "<script>alert('Book Already Issued');</script>";
 }
 else
 {
  foreach($book_id as $bookid){
    $sql ="SELECT BookName,ISBNNumber FROM tblbooks WHERE (ISBNNumber=:bookid)";
$query= $dbh -> prepare($sql);
$query-> bindParam(':bookid', $bookid, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
$cnt=1;
  
if($query -> rowCount() > 0)
{
  foreach ($results as $result) {?>
<option selected value="<?php echo htmlentities($result->ISBNNumber);?>"><?php echo htmlentities($result->BookName);?></option>
<b>Book Name :</b> 
  
<?php  
echo htmlentities($result->BookName);
 echo "<script>$('#submit').prop('disabled',false);</script>";
}
}

 else{?>
  
<option class="others"> Invalid ISBN Number</option>
<?php
 echo "<script>$('#submit').prop('disabled',true);</script>";
}
}
}
}


?>
