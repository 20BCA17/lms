<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/sidebar.php";
?>



<html>

<head>

</head>

<body>
    <div id="wrapper">
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                           NewsPaper
                        </h1>
                    </div>


                </div>
                <div class="row " >
                    <div class="col-lg-9">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Laboratory Management
                            </div>
                            <div class="panel-body  ">
                                <div class="form-row">
                                    <div class="col-lg-12 ">
                                <form method="POST">
                                    <div class="form-group">
                                        <?php
                                             include '../db.php';
                                             $data = mysqli_query($con, "select * from tbladdnewspaper");
                                        foreach ($data as $value) {
                                            echo "<div class='form-group'>";
                                            echo "<input type='checkbox'value='$value[newspaper]' name='newsname[]''>&nbsp; &nbsp;<strong>$value[newspaper]</strong>";
                                            echo "</div>";
                                        }
                                        ?>
                                    </div>
                                    <!-- <div class="form-group">
                                        <input type="checkbox" value="GUJARAT SAMACHAR" name="newsname[]">&nbsp; &nbsp;<strong>GUJARAT SAMACHAR</strong>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" value="GUJARAT MITRA" name="newsname[]">&nbsp; &nbsp;<strong>GUJARAT MITRA</strong>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" value="SANDESH" name="newsname[]">&nbsp; &nbsp;<strong>SANDESH</strong>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" value="DIVYA BHASKAR" name="newsname[]">&nbsp; &nbsp;<strong>DIVYA BHASKAR</strong>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" value="TIMES OF INDIA" name="newsname[]">&nbsp; &nbsp;<strong>TIMES OF INDIA</strong>
                                    </div>-->
                                    <div class="form-group">
                                        <input type="DATE" class="form-control" name="newsdate">
                                    </div>
                                    <div class="form-group">
                                    <button class="btn btn-info" name="btnnewspaper" type="submit">Add</button>
                                    </div>
                                        </div>
                                    </div>
                                </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html>


<?php
include "include/script.php";
?>
<?php
include '../db.php';
if (isset($_POST["btnnewspaper"])) {

    $checkbox1 = $_POST['newsname'];
    $chk = "";
    foreach ($checkbox1 as $chk1) {
        $chk .= $chk1 . ",";
    }


    $newsdate = ($_POST['newsdate']);

    $query = "INSERT INTO `tblnewspaper` (newsname,newsdate) VALUES ('$chk','$newsdate')";

    $result = mysqli_query($con, $query);
    if ($result) {
        echo "<script>alert('NewsPaper inserted');
        window.location.href='Manage_Newspaper.php'</script>";?>

       
<?php } else {
        echo "<script>alert('NewsPaper not inserted');</script>";
    }
}
?>
