<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>

<?php
include "../auth.php";
include "include/header.php";
include "include/sidebar.php";
?>


<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        MANAGE REG FACULTIES
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <a href="Student_faculty_reg.php" class="btn btn-info">Faculty_Registration</a>
                            </div>  
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 table-responsive">
                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Faculty ID</th>
                                                <th>Faculty Name</th>
                                                <th>Email Id</th>
                                                <th>Mobile Number</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                            <?php
                                            $num=1;
                                            include "../db.php";
                                            $select = "SELECT * FROM tblfaculties";
                                            $run = mysqli_query($con, $select);
                                            while ($row = mysqli_fetch_assoc($run)) {
                                                $id = $row['id'];
                                                $SfId = $row['SfId'];
                                                $FullName = $row['FullName'];
                                                $EmailId = $row['EmailId'];
                                                $MobileNumber = $row['MobileNumber'];
                                                $Status = $row['Status'];
                                            ?>
                                            
                                            
                                                <td><?php echo $num ?></td>
                                                <td><?php echo $SfId ?></td>
                                                <td><?php echo $FullName ?> </td>
                                                <td><?php echo $EmailId ?></td>
                                                <td><?php echo $MobileNumber ?></td>
                                                <td><?php if($row['Status']==1)
                                                { 
                                                    echo "<span style='color:green';>Active</span>";
                                                }
                                                else {
                                                    echo "Blocked";
                                                }
                                                ?></td>
                                                <td><?php
                                                         if($row['Status']==0){
                                                            echo  '<p><a href="Faculty_Status.php?SfId='.$row['SfId'] .'&Status=1" class="btn btn-success btn-sm">Active</a></p>';
                                                         }
                                                         else{
                                                            echo  '<a href="Faculty_Status.php?SfId='.$row['SfId'] .'&Status=0" class="btn btn-danger btn-sm">Deactive</a>';

                                                         }
                                                        ?></td>
                                            
                                        </tr>
                                            <?php $num++;} ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php
include "include/script.php";
?>