<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "include/header.php";
include "include/sidebar.php";
?>


<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Edit Book
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Book Info
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 ">
                                        <div class="form-group">


                                            <div class="col-md-4">
                                                <label for="">Book Name</label>
                                                <input type="text" class="form-control">
                                            </div>
                                            <div class="col-md-4 ">
                                                <label for="">Category</label>
                                                <!-- <input type="text" name="" id="" class="form-control"> -->
                                                <select class="form-control">
                                                    <option>Select Category</option>
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="">Author</label>
                                                <!-- <input type="text" name="" id="" class="form-control"> -->
                                                <select class="form-control">
                                                    <option>Select Author</option>
                                                </select>
                                            </div>
                                        </div>
                                        <br><br><br>
                                        <div class="form-group">


                                            <div class="col-md-4">
                                                <label for="">Accession Number</label>
                                                <input type="text" name="" id="" class="form-control" placeholder="Accession Must be unique">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="">Price</label>
                                                <input type="text" name="" id="" class="form-control">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="">Bill Number</label>
                                                <input type="text" name="" id="" class="form-control">
                                            </div>
                                        </div><br><br><br>
                                        <div class="form-group">

                                            <div class="col-md-4">
                                                <label for=""> Bill Date</label>
                                                <input type="date" name="" id="" class="form-control">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="">Publisher</label>
                                                <input type="text" name="" id="" class="form-control">
                                            </div>

                                        </div>
                                        <div class="col-md-12"><br>
                                            <button class="btn btn-info">Save</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php
include "include/script.php";
?>