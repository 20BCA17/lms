<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/script.php";
include "include/sidebar.php";
?>
<?php
include '../db.php';
error_reporting(0);
$select = "SELECT * FROM `web_seting` ";
$run = mysqli_query($con, $select);
$row = mysqli_fetch_assoc($run);
$index_img = $row['index_img'];
$Description = $row['Description'];


?>

<div id="wrapper">

   
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Web <small>Settings</small>
                    </h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Website Setting
                        </div>
                        <div class="panel-body">
                            <div class="form-row">
                                <div class="col-lg-12">
                                    <form action="" method="post" enctype="multipart/form-data">
                                        <div class="coanteinr">


                                            <div class="form-group">


                                                <script type="text/javascript">
                                                    function preview(event) {
                                                        var reader = new FileReader();
                                                        reader.onload = function() {
                                                            var output = document.getElementById('output_image');
                                                            output.src = reader.result;
                                                        }
                                                        reader.readAsDataURL(event.target.files[0]);
                                                    }
                                                </script>
                                                    
                                                <img id="output_image" height=150px width=700px src="img/<?php echo $row['index_img']; ?>">
                                                <input name="index_img" type="file" id="choose" style="display: none;" onchange="preview(event)" accept="image/*" value="img/" /><br><br>
                                                <label for="choose" class="custom-file-upload btn btn-info btn-sm" id="choose-label">Change Image</label>

                                            </div>
                                            <hr>
                                            <div class="form-group ">
                                                <label for="">Page title</label>
                                             <input type="text" name="title" id="" class="form-control" value="<?php echo $row['title']; ?>">
                                            </div>

                                            <div class="form-group responsive">
                                                <label for="">Page Description</label>
                                                <textarea name="Description" id="" cols="30" rows="10" class="form-control"><?php echo $Description; ?></textarea>
                                                
                                            </div>
                                            
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                                            </div>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
</div>
<script src="js/niceedit.js" type="text/javascript"></script>
    <script type="text/javascript">
        bkLib.onDomLoaded(nicEditors.allTextAreas);
    </script>
<?php
include '../db.php';
if (isset($_POST["submit"])) {
    // $index_img=($_POST['index_img']); 
    $title = ($_POST['title']);
    $Description = ($_POST['Description']);
    if ($_FILES['index_img']['name'] != "") {

        $name = $_FILES['index_img']['name'];
        list($txt, $ext) = explode(".", $name);
        $image_name = $txt . "." . $ext;
        $tmp = $_FILES['index_img']['tmp_name'];
        $res = mysqli_query($con, "SELECT* from web_seting ");
        if ($row = mysqli_fetch_array($res)) {
            $deleteimage = $row['index_img'];
        }
        unlink('img/' . $deleteimage);
        move_uploaded_file($tmp, 'img/' . $image_name);
        

        $query = "UPDATE  `web_seting` set index_img='$image_name',title='$title',Description='" . $_POST['Description'] . "' ";


        //  $update = "UPDATE `tblauthors` SET AuthorName='".$_POST['AuthorName']."' WHERE id=$author_id";

        $result   = mysqli_query($con, $query);

        if ($result) {
            echo "<script>alert('update successfully ');</script>";
?>
            <script>
                window.location.href = 'Web_setting.php';
            </script>
<?php } else {
            echo "<script>alert('something went wrong please try again');</script>";
        }
    } else {
        $query = "UPDATE  `web_seting` set title='$title',Description='" . $_POST['Description'] . "' ";

        $result   = mysqli_query($con, $query);
        echo "<script>alert('update successfully ');
    window.location.href = 'Web_setting.php';</script>";
    }
}

?>