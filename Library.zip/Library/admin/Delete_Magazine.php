<?php
	include('../db.php');
	if(isset($_GET['id']))
	{
		$id = $_GET['id'];
		$delete = "delete from `tblmagazine` where id=$id";
		$res = mysqli_query($con,$delete);
        
		if($res)
		{
			echo "<script>alert('Magazine Deleted');</script>";?>
        <script>
            window.location.href='Manage_Magazine.php';
        </script>
		<?php }
		else
		{
            echo "<script>alert('Magazine Does not Deleted');</script>";
		}
	}
?>