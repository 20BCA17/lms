<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/script.php";
include "include/sidebar.php";
?>

<?php
 include '../db.php';
$author_id = $_GET['id'];
$select = "SELECT * FROM `tblauthors` WHERE id=$author_id";
$run = mysqli_query($con, $select);
$row = mysqli_fetch_assoc($run);
$AuthorName = $row['AuthorName'];


?>

<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                       Add Author
                    </h1>
                </div>
                <div class="row">
                    <div class="col-md-10">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                            Update  Author Info
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-md-12 ">
                                        <div class="form-group">

                                        <form method="POST">
                                            <div class="col-md-12">
                                                <label for="">Author Name</label>
                                                <input type="text" class="form-control" name="AuthorName" value="<?php echo $AuthorName; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-12"><br>
                                        <input type="submit" class="btn btn-info" name="btnAuthor" value="Update" />
                                        </div>
                                        <br><br><br>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>


<?php
 if (isset($_POST["btnAuthor"])) {
    $update = "UPDATE `tblauthors` SET AuthorName='".$_POST['AuthorName']."' WHERE id=$author_id";
    $run2 = mysqli_query($con, $update);
    if($run2){
        echo "<script>alert('Author Updated');</script>";?>
        <script>
            window.location.href='Manage_Authors.php';
        </script>
    <?php }
    else{
        echo "<script>alert('Author Not Updated');</script>";
    }
    }
    ?>