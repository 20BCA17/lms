
<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/sidebar.php";
?>


<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Manage Journals
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <a class="btn btn-info" href="Add_Journal.php" style="color: white; text-decoration: none;">New Journal</a>
                               
                                <a href="Export/Journal.php" class="btn btn-info">Download Report</a>
                            </div>  
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 table-responsive ">
                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Journal Name</th>
                                                <th>Category</th>
                                                <th>Issue Number</th>
                                                <th>Price</th>
                                                <th>Bill Date</th>
                                                <th>Publisher</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                            <?php
                                            $num=1;
                                            include "../db.php";
                                            $select = "SELECT * FROM tbljournal";
                                            $run = mysqli_query($con, $select);
                                            while ($row = mysqli_fetch_assoc($run)) {
                                                $id = $row['id'];
                                                $JournalName = $row['JournalName'];
                                                $CatId = $row['CatId'];
                                                $IssueNo = $row['IssueNo'];
                                                $Price = $row['Price'];
                                                $Date = $row['Date'];
                                                $Publisher = $row['Publisher'];
                                            ?>
                                          
                                            
                                                <td><?php echo $num ?></td>
                                                <td><?php echo $JournalName ?></td>
                                                <td><?php $catName = "SELECT * FROM `tblcategory` WHERE id='$CatId'";
                                                $run2 = mysqli_query($con, $catName);
                                                while($row2 = mysqli_fetch_assoc($run2)){
                                                    $name = $row2['CategoryName'];
                                                    echo $name;
                                                } ?></td>
                                                  
                                                <td><?php echo $IssueNo ?></td>
                                                <td><?php echo $Price ?></td>
                                                <td><?php echo $Date ?></td>
                                                <td><?php echo $Publisher ?></td>
                                               

                                                <td>  <a style="text-decoration: none; color:white;" class="btn btn-info btn-sm" href="Update_Journal.php?id=<?php echo $id; ?>"><i class="fa fa-edit fa-fw" ></i>Edit</a>
                                                       <a class="btn btn-danger btn-sm"  style="text-decoration: none; color:white;" href="Delete_Journal.php?id=<?php echo $id; ?>" ><i class="fa fa-trash fa-fw"></i>Delete</a>
                                                        </td>
                                            </tr>
                                            
                                            <?php $num++;} ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php
include "include/script.php";
?>