<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/script.php"; 
include "include/sidebar.php";
?>

<?php
 include '../db.php';
$category_id = $_GET['id'];
$select = "SELECT * FROM `tblcategory` WHERE id=$category_id";
$run = mysqli_query($con, $select);
$row = mysqli_fetch_assoc($run);
$category_name = $row['CategoryName'];
$status = $row['Status'];
?>


<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Update Category
                    </h1>
                </div>
                <div class="row">
                    <div class="col-md-10">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               Update Category Info
                            </div>
                            
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-md-12 ">
                                        <div class="form-group">

                                            <form  method="POST" action="<?php $_SERVER['PHP_SELF']; ?>">
                                            <div class="col-md-12">
                                                <label for="">Category Name</label>
                                                <input type="text" class="form-control" name="CategoryName" value="<?php echo $category_name; ?>" required>
                                            </div>
                                            <div class="col-md-12"><br>
                                                <label for="">Status</label><br>
                                                <input type="radio" name="Status" <?php if ($row['Status'] == "active") {?>
                                                   checked="true" <?php } ?> value="active">Active<br>
                                                <input type="radio" name="Status" <?php if ($row['Status'] == "inactive") {?>
                                                   checked="true" <?php } ?> value="inactive">Inactive
                                            </div>
                                        </div>
                                        <br><br><br>
                                        <div class="col-md-12"><br>
                                            <input type="submit" class="btn btn-info" name="btnCategory" value="Update" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>



<?php 


 if (isset($_POST["btnCategory"])) {
    // $CategoryName = $POST['CategoryName'];
    // $Status = $POST['Status'];
    $update = "UPDATE `tblcategory` SET CategoryName='".$_POST['CategoryName']."',Status='".$_POST['Status']."' WHERE id=$category_id";
    $run2 = mysqli_query($con, $update);
    if($run2){
        echo "<script>alert('Category Updated');</script>";?>
        <script>
            window.location.href='Manage_Category.php';
        </script>
    <?php }
    else{
        echo "<script>alert('Something went wrong. Please try again');</script>";
    }
    }
   
    ?>
