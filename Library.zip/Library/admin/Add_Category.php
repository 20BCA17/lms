<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/script.php";
include "include/sidebar.php";

?>






<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Add Category
                    </h1>
                </div>
                
                <div class="row">
                    <div class="col-md-10">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Category Info
                            </div>
                            
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-md-12 ">
                                        <div class="form-group">
                                            <form  method="POST" action="<?php $_SERVER['PHP_SELF']; ?>" id="reg" autocomplete="off">

                                            <div class="col-md-12">
                                                <label for="">Category Name</label>
                                                <input type="text" class="form-control" name="CategoryName" required>
                                            </div>
                                            <div class="col-md-12"><br>
                                                <label for="">Status</label><br>
                                                <input type="radio" name="Status" value="active" >Active<br>
                                                <input type="radio" name="Status" value="inactive">Inactive
                                            </div>
                                            <br><br><br>
                                        <div class="col-md-12"><br>
                                            <input type="submit" class="btn btn-info" name="btnCategory" value="Save" />
                                        </div>
                                    </form>
                                        </div>

                                       
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php

include "../include/validation.php";
include "../include/validation_css.php";
?>
<?php
 include '../db.php';
 if (isset($_POST["btnCategory"])) {
        $CategoryName=($_POST['CategoryName']); 
        $Status=($_POST['Status']);

        $query    = "INSERT into `tblcategory` (CategoryName,Status)
        VALUES ('$CategoryName','$Status')";
                     
        $result   = mysqli_query($con, $query);
        if ($result) {
            echo "<script>alert('category inserted');</script>";?>
            <script>
                window.location.href='Manage_Category.php';
            </script>
        <?php } else {
            echo "<script>alert('Something went wrong. Please try again');</script>";
        }
    }
?>

