
<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>

<?php

include "../include/icon.php";

include "../include/validation_css.php";

?>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require('../PHPMailer/Exception.php');
require('../PHPMailer/SMTP.php');
require('../PHPMailer/PHPMailer.php');
 if (isset($_POST["reg"])) {
    include '../db.php';
    // When form submitted, insert values into the database.
  
        // removes backslashes
    
        $SfId = stripslashes($_REQUEST['SfId']); 
        $SfId = mysqli_real_escape_string($con, $SfId);

        $FullName    = stripslashes($_REQUEST['FullName']);
        $FullName    = mysqli_real_escape_string($con, $FullName);

        $Status    = stripslashes($_REQUEST['Status']);
        $Status    = mysqli_real_escape_string($con, $Status);

        $EmailId = stripslashes($_REQUEST['EmailId']);
        $EmailId = mysqli_real_escape_string($con, $EmailId);

        $MobileNumber = stripslashes($_REQUEST['MobileNumber']);
        $MobileNumber = mysqli_real_escape_string($con, $MobileNumber);

        $Password = stripslashes($_REQUEST['Password']);
        $Password = mysqli_real_escape_string($con, $Password);
        
		$mail = new PHPMailer(true);

		

try {
    //Server settings
    // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'dubenitin445@gmail.com';                     //SMTP username
    $mail->Password   = 'ciruwmgrogqvedwc';                               //SMTP password
             //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('dubenitin445@gmail.com', 'To Nitin');
    $mail->addAddress("$EmailId");     //Add a recipient
  

    //Attachments
    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'VTCBCSR Library Registration';
    $mail->Body    = "<h3 style='color:blue;'>Registration Successfully</h3>
    <table border=2  style='width: 300px;margin: auto; padding: 8px; margin-bottom: 10px;'>
    <thead>
    <tr>
        <th>UserName </th>
        <td>$EmailId</td>
    </tr>
</thead>
<tbody>
    <tr>
        <th>Password</th>
        <td>$Password</td>
    </tr>
</tbody>
</table><br>
<p>Thank You for Registration</p>
<br>
Login Vtcbcsr Library &nbsp;<a href='login.php' style='text-decoration:none;color:blue; '>Click here</a>";
    // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

        if(!preg_match ("/^[0-9]*$/",$SfId)==$SfId){
            $query    = "INSERT into `tblstudents` (SfId  ,FullName,Status, EmailId, MobileNumber , Password)
            VALUES ('$SfId','$FullName','$Status',  '$EmailId', '$MobileNumber', '" . md5($Password) . "')";
        }
        else{
            $query    = "INSERT into `tblfaculties` (SfId  ,FullName,Status, EmailId, MobileNumber , Password)
            VALUES ('$SfId','$FullName','$Status',  '$EmailId', '$MobileNumber', '" . md5($Password) . "')";
        }
       
             
        $result   = mysqli_query($con, $query);
        if ($result) {
            
            header("Location:Faculty.php");
        } else {
            echo "failed";
        }


    }
    
    function get_password($str, $len = 0)
    {

        // Variable $pass to store password
        $pass = "";

        // Variable $str_length to store
        // length of the given string
        $str_length = strlen($str);

        // Check if the $len is not provided
        // or $len is greater than $str_length
        // then assign $str_length into $len
        if ($len == 0 || $len > $str_length) {
            $len = $str_length;
        }

        // Shuffle the string
        $pass = str_shuffle($str);

        // Extract the part of string
        $pass = substr($pass, 0, $len);

        return $pass;
    }

    // Print password of length 5 from
    // the given string
    $str = "12365479963258741159875364573196428197342665232494232324972323564697946132959599";

?>
<?php

include '../db.php';


$sql = ("SELECT * FROM tblfaculties");

if ($result = mysqli_query($con, $sql)) {

    $rowcount = mysqli_num_rows($result);

    //   printf(" %d\n", );
}

// Close the connection
mysqli_close($con);

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login V8</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form p-l-55 p-r-55 p-t-178" method="POST" action="<?php $_SERVER['PHP_SELF']; ?>" id="reg">
					<span class="login100-form-title">
						 Sign Up
					</span>

					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100" type="text"  placeholder="Faculty Id" name="SfId" id="myInput" required value="<?php echo $rowcount +1?>">
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100" type="text" name="FullName" placeholder="SURNAME FRISTNAME LASTNAME" required>
						<input type="hidden" class="form-control"  name="Status" value="1" />
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100" type="text"  name="EmailId" id="email_address"  required placeholder="Enter Email ID" data-parsley-type="email" data-parsley-trigger="focusout" data-parsley-checkemail data-parsley-checkemail-message="Email Address already Exists" >
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100 input_text" type="text" name="MobileNumber" data-minlength="10" maxlength="10" id="mobile" data-parsley-minlength="10" data-parsley-minlength-message="minlength 10 number" data-parsley-type="digits" data-parsley-type-message="only numbers" placeholder="Phone Number" required>
						<span class="focus-input100"></span>
					</div>
				

					<div class="wrap-input100 validate-input m-b-16" data-validate = "Please enter password">
						<input class="input100" type="text" name="Password" id="password" placeholder="Password" required data-parsley-length="[4, 6]" data-parsley-trigger="keyup" value="<?php echo get_password($str, 5); ?>" readonly>
						<span class="focus-input100"></span>
					</div>

				
					
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" type="submit" name="reg">
						Register
						</button>
					</div>

					<div class="flex-col-c p-t-170 p-b-40">
						<span class="txt1 p-b-9">

						</span>

						
					</div>
				</form>
			</div>
		</div>
	</div>
	
	


</body>
</html>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.8.0/parsley.js"></script>

    <?php
include "../include/validation.php";
include "../include/validation.php";

?>