<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/script.php";
include "include/sidebar.php";

?>



<!DOCTYPE html>
<html>

<head>

    <script>
        // function for get student name
        function getstudent() {
            $("#loaderIcon").show();
            jQuery.ajax({
                url: "get_student.php",
                data: 'SfId=' + $("#SfId").val(),
                type: "POST",
                success: function(data) {
                    $("#get_student_name").html(data);
                    $("#loaderIcon").hide();
                },
                error: function() {}
            });
        }

        //function for book details
        function getbook() {
            $("#loaderIcon").show();
            var bookid = $('#bookid').val();
            jQuery.ajax({
                url: "get_book.php",
                data: 'bookid=' + bookid,
                type: "POST",
                success: function(data) {
                    console.log(data);
                    $("#get_book_name").html(data);
                    $("#loaderIcon").hide();
                },
                error: function() {}
            });
        }
    </script>
    <style type="text/css">
        .others {
            color: red;
        }
    </style>


</head>


<body>


    <div id="wrapper">
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Issue a New Book
                        </h1>
                    </div>
                    <div class="row">
                        <div class="col-md-11">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    Issue a New Book
                                </div>
                                <div class="panel-body">
                                    <div class="form-row">
                                        <div class="col-md-12 ">
                                            <div class="form-group">
                                                <form id="reg" role="form" method="POST">

                                                    <div class="form-group">
                                                        <label>User ID<span style="color:red;">*</span></label>
                                                        <input class="form-control" type="text" name="SfId" id="SfId" onBlur="getstudent()" autocomplete="off" required />
                                                    </div>

                                                    <div class="form-group">
                                                        <span id="get_student_name" style="font-size:16px;"></span>
                                                    </div>





                                                    <div class="form-group">
                                                        <label>Accession Number<span style="color:red;">*</span></label>
                                                        <input class="form-control" type="text" name="bookid" id="bookid" onBlur="getbook()" required="required" autocomplete="off" />
                                                    </div>

                                                    <div class="form-group">

                                                        <select class="form-control" name="bookdetails[]" multiple id="get_book_name" readonly>

                                                        </select>
                                                    </div>
                                                    <div class="form-group">

                                                        <input type="submit" class="btn btn-info" name="issue" value="Issue Book" id="submit" />
                                                    </div>

                                                </form>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>



            </div>

        </div>
    </div>

    <?php

    include "../include/validation.php";
    include "../include/validation_css.php";

    ?>

</body>

</html>

<?php
include "db.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require('../PHPMailer/Exception.php');
require('../PHPMailer/SMTP.php');
require('../PHPMailer/PHPMailer.php');

if (isset($_POST['issue'])) {
    $SfId = strtoupper($_POST['SfId']);
    $stdName = "SELECT * FROM `tblfaculties` WHERE SfId='$SfId' union SELECT * FROM `tblstudents` WHERE SfId='$SfId'";
    $run2 = mysqli_query($con, $stdName);
    while ($row2 = mysqli_fetch_assoc($run2)) {
        $FullName = $row2['FullName'];
        $EmailId = $row2['EmailId'];
    }
    $book_id = $_POST['bookdetails'];


    $mail = new PHPMailer(true);

// Email send issud book

    try {
                             
        $mail->isSMTP();                                           
        $mail->Host       = 'smtp.gmail.com';                   
        $mail->SMTPAuth   = true;                                  
        $mail->Username   = 'dubenitin445@gmail.com';                    
        $mail->Password   = 'ciruwmgrogqvedwc';                              
       
        $mail->Port       = 587;                                   

       
        $mail->setFrom('dubenitin445@gmail.com', 'vtcbcsr');
        $mail->addAddress("$EmailId");     
// book issued date time
date_default_timezone_set('Asia/Kolkata');
$date = date('d-m-y h:i:s');


        echo 'Message has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
    if (!preg_match("/^[0-9]*$/", $SfId) == $SfId) {
        foreach ($book_id as $bookid) {
            $sql = "INSERT INTO  `tblissuebookstudents`(SfId,BookId) VALUES(:SfId,:bookid)";

            $query = $dbh->prepare($sql);
            $query->bindParam(':SfId', $SfId, PDO::PARAM_STR);
            $query->bindParam(':bookid', $bookid, PDO::PARAM_STR);

            $query->execute();
            $Bookname = "SELECT * FROM `tblbooks` WHERE ISBNNumber='$bookid'";
            $run3 = mysqli_query($con, $Bookname);
            while ($row3 = mysqli_fetch_assoc($run3)) {
                $BookName = $row3['BookName'];
                $sql1 = "INSERT INTO  `tblissuebookstore`(SfId,BookName,BookId) VALUES(:SfId,:BookName,:bookid)";

                $query1 = $dbh->prepare($sql1);
                $query1->bindParam(':SfId', $SfId, PDO::PARAM_STR);
                $query1->bindParam(':BookName', $BookName, PDO::PARAM_STR);
                $query1->bindParam(':bookid', $bookid, PDO::PARAM_STR);
               
    
                $query1->execute();
                $mail->isHTML(true);                                  //Set email format to HTML
                $mail->Subject = 'Library Book Issued';
                $mail->Body    = "<h3 style='color:green';>Successfully Received Book</h3><br>
                <table border=2 style='width: 500px;margin: auto; padding: 8px; margin-bottom: 10px;' >
                <thead>
                    <tr>
                        <th>id</th>
                        <td>$SfId</td>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td>$FullName</td>
                    </tr>
                    <tr>
                        <th>Accession Number</th>
                        <td>$bookid</td>
                    </tr>
                    <tr>
                        <th>BookName </th>
                        <td>$BookName</td>
                    </tr>
                    <tr>
                        <th>Book Recived Date</th>
                        <td>$date</td>
                    </tr>
                    
                </thead>
            </table>
            <br>
            <p>We expect you to return the book at the end of the semester exactly as you received it.</p><br>
            <p>Thank you</p>";
                // $mail->send();
            }
        }
        $lastInsertId = $dbh->lastInsertId();
        if ($lastInsertId) {
          
            echo '<script>alert("Book issued successfully ")
                window.location.href="Manage_Issue_Book_Student.php";</script>';
        } else {

            echo '<script>alert("Something went wrong. Please try again")
                window.location.href="Manage_Issue_Book_Student.php";</script>';
        }
    } else {
        foreach ($book_id as $bookid) {
            $sql = "INSERT INTO  `tblissuebookdetails`(SfId,BookId) VALUES(:SfId,:bookid)";

            $query = $dbh->prepare($sql);
            $query->bindParam(':SfId', $SfId, PDO::PARAM_STR);
            $query->bindParam(':bookid', $bookid, PDO::PARAM_STR);

            $query->execute();
            $Bookname = "SELECT * FROM `tblbooks` WHERE ISBNNumber='$bookid'";
            $run3 = mysqli_query($con, $Bookname);
            while ($row3 = mysqli_fetch_assoc($run3)) {
                $BookName = $row3['BookName'];
                $sql1 = "INSERT INTO  `tblissuebookstore`(SfId,BookName,BookId) VALUES(:SfId,:BookName,:bookid)";

                $query1 = $dbh->prepare($sql1);
                $query1->bindParam(':SfId', $SfId, PDO::PARAM_STR);
                $query1->bindParam(':BookName', $BookName, PDO::PARAM_STR);
                $query1->bindParam(':bookid', $bookid, PDO::PARAM_STR);
               
    
                $query1->execute();
                $mail->isHTML(true);                                  //Set email format to HTML
                $mail->Subject = 'Library Book Issued';
                $mail->Body    = "<h3 style='color:green';>Successfully Received Book</h3><br>
                <table border=2 style='width: 500px;margin: auto; padding: 8px; margin-bottom: 10px;' >
                <thead>
                    <tr>
                        <th>id</th>
                        <td>$SfId</td>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td>$FullName</td>
                    </tr>
                    <tr>
                        <th>Accession Number</th>
                        <td>$bookid</td>
                    </tr>
                    <tr>
                        <th>BookName </th>
                        <td>$BookName</td>
                    </tr>
                    <tr>
                        <th>Book Recived Date</th>
                        <td>$date</td>
                    </tr>
                    
                </thead>
            </table>
            <br>
            <p>We expect you to return the book at the end of the semester exactly as you received it.</p><br>
            <p>Thank you</p>";
                // $mail->send();
            }
        }


        $lastInsertId = $dbh->lastInsertId();
        if ($lastInsertId) {

            echo '<script>alert("Book issued successfully ")
                window.location.href="Manage_Issue_Book.php";</script>';
        } else {


            echo '<script>alert("Something went wrong. Please try again")
                window.location.href="Manage_Issue_Book.php";</script>';
        }
    }
}



?>