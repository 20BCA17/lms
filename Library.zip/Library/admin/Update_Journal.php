<?php
include_once '../db.php';
$result = mysqli_query($con, "SELECT * FROM admin ");
$row = mysqli_fetch_array($result);

?>
<?php
session_start();
error_reporting(0);
include('../db.php');
if (strlen($_SESSION['EmailId'] != $row['EmailId'])) {
    header('location:login.php');
    
}

?>
<?php
include "../auth.php";
include "include/header.php";
include "include/script.php";
include "include/sidebar.php";
?>

<?php
 include '../db.php';
 $journal_id = $_GET['id'];
 $select = "SELECT * FROM `tbljournal` WHERE id=$journal_id";
$run = mysqli_query($con, $select);
$row = mysqli_fetch_assoc($run);
$journal_id = $_GET['id'];
$JournalName = $row['JournalName'];
$CatId = $row['CatId'];
$IssueNo = $row['IssueNo'];
$Price = $row['Price'];
$Date = $row['Date'];
$Publisher = $row['Publisher'];


?>

<script>
    if(window.history.replaceState){
        window.history.replaceState(null,null,window.location.href)
    }
</script>

<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Update Journal
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               Update Journal Info
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 ">
                                    <form action="" method="POST">
                                        <div class="form-group">
                                        

                                                <div class="col-md-4">
                                                    <label for="">Journal Name</label>
                                                    <input type="text" class="form-control" name="JournalName" value="<?php echo $JournalName; ?>">
                                                </div>
                                               
                                                <div class="col-md-4 ">
                                                    <label for="">Category</label>
                                                  <?php
                                                   include 'db.php';
                                                   $data = mysqli_query($con, "select * from tblcategory");
                                                   echo "<select name='CatId' class='selectpicker form-control' data-show-subtext='true' data-live-search='true' >name</option>";
                                              
                                                
                                                   foreach($data as $value){
                                                       if($CatId == $value['id']){
                                                            echo "<option value='$value[id]' selected readonly>$value[CategoryName]</option>";
                                                        }
                                                       echo "<option value='$value[id]'>$value[CategoryName]</option>";
                                                   }
                                                   echo "</select>";
                                                   
                                                   ?>
                                                
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="">Issue Number</label>
                                                    <input type="text" name="IssueNo" id="" class="form-control" placeholder="Issue Number Must be unique" value="<?php echo $IssueNo; ?>">
                                                </div>
                                        </div>
                                        <br><br><br>
                                        <div class="form-group">


                                            <div class="col-md-4">
                                                <label for="">Price</label>
                                                <input type="text" name="Price" id="" class="form-control" value="<?php echo $Price; ?>">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="">Date</label>
                                                <input type="date" name="Date" id="" class="form-control" value="<?php echo $Date; ?>">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="">Publisher</label>
                                                <input type="text" name="Publisher" id="" class="form-control" value="<?php echo $Publisher; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-12"><br>
                                        <!-- <input type="submit" name="btnjournal" value="Add" class="btn btn-info"> -->
                                        <button class="btn btn-info" name="btnjournal" type="submit">Update</button>
                                        </div>
                                    </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </div>

    </div>
</div>

<?php

if (isset($_POST["btnjournal"])) {
    // $CategoryName = $POST['CategoryName'];
    // $Status = $POST['Status'];
    $update = "UPDATE `tbljournal` SET JournalName='".$_POST['JournalName']."',CatId='".$_POST['CatId']."',IssueNo='".$_POST['IssueNo']."',Price='".$_POST['Price']."',Date='".$_POST['Date']."',Publisher='".$_POST['Publisher']."' WHERE id=$journal_id";
    $run2 = mysqli_query($con, $update);
    if($run2){
        echo "<script>alert('Journal Updated')
        window.location.href='Manage_Journal.php';</script>";?>
       
    <?php }
    else{
        echo "<script>alert('Something went wrong. Please try again');</script>";
    }
    }
    ?>