<?php
	include '../db.php';
	$ISBNNumber=$_POST['ISBNNumber'];
	$sql = "DELETE FROM tblbooks WHERE ISBNNumber=$ISBNNumber";

	// $sql = "DELETE FROM `tblbooks` WHERE NOT EXISTS (SELECT * FROM tblissuebookdetails WHERE tblissuebookdetails.BookId=$ISBNNumber UNION SELECT * FROM tblissuebookstudents WHERE tblissuebookstudents.BookId=$ISBNNumber) && ISBNNumber=$ISBNNumber";


	if (mysqli_query($con, $sql)) {
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}

	

	mysqli_close($con);
?>
