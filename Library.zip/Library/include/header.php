    <?php
    include 'db.php';
    error_reporting(0);
    $select = "SELECT * FROM `web_seting` ";
    $run = mysqli_query($con, $select);
    $row = mysqli_fetch_assoc($run);
    $title = $row['title'];
   
    ?>
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title><?php echo $row['title']; ?></title>

        <!--title icon-->
        <link rel="icon" type="image/x-icon" href="https://www.pngitem.com/pimgs/m/665-6657133_library-management-system-logo-png-transparent-png.png">
        <!-- Bootstrap Styles-->
        <link href="assets/css/bootstrap.css" rel="stylesheet" />
        <!-- FontAwesome Styles-->
        <link href="assets/css/font-awesome.css" rel="stylesheet" />
            <!-- Custom Styles-->
        <link href="assets/css/custom-styles.css" rel="stylesheet" />
        <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

    <!-- font awesome-->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

            <!-- TABLE STYLES-->
            <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

        
    </head>
