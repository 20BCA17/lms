<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.8.0/parsley.js"></script> -->
    <script src="http://parsleyjs.org/dist/parsley.js"></script>
<script>
    $("#reg").parsley();
</script>

    <script>
    $(document).ready(function() {
        $('#email_address').parsley();
        window.ParsleyValidator.addValidator('checkemail', {
            validateString: function(value) {
                return $.ajax({
                    url: 'fetchData.php',
                    method: "POST",
                    data: {
                        email: value
                    },
                    dataType: "json",
                    success: function(data) {
                        return true;
                    }
                });
            }
        });
    });
</script>

