<?php
$con = new mysqli('localhost','root','','library');
// $con = new mysqli('sql110.byetcluster.com','epiz_34027242','bhC8bPFI6wyA3','epiz_34027242_vlms');

if(!$con){
    die("Error on the connectioin ". $con ->connect_error);
}
?>