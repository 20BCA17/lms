
<?php
include "auth.php";
include "include/header.php";
include "include/sidebar.php";
?>


<div id="wrapper">
    <div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Book List
                    </h1>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                           <span>Book List</span>
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12 ">
                                        <?php include 'db.php' ?>
                                        <?php $data = mysqli_query($con, "select * from tblbooks") ?>

                                        </script>
                                        <div class="table-responsive">
                                            <table id="dataTables-example" class="table table-striped table-bordered table-hover ">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>BookName</th>
                                                        <th>CatId</th>
                                                        <th>AuthorId</th>
                                                        <th>ISBNNumber</th>
                                                        <th>BookPrice</th>
                                                        <th>BillNo</th>
                                                        <th>BillDate</th>
                                                        <th>Publisher</th>
                                                        <th>Status</th>

                                                    </tr>
                                                </thead>


                                            </table>
                                        </div>
                                        <?php 
                                        $da= "select * from tblissuebookdetails where "


?>
                                        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
                                        <script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.js" charset="utf8" type="text/javascript"></script>
                                       


                                        <script type="text/javascript">
                                            var i = 1;
                                            $(document).ready(function() {


                                                $('#dataTables-example').dataTable({

                                                    "processing": true,


                                                    "ajax": "BookFetch.php",
                                                    "columns": [{
                                                            "render": function(data, type, full, meta) {
        return i++;
      }
                                                        },
                                                        {
                                                            data: 'BookName'
                                                        },
                                                        {
                                                            data: 'CatId'
                                                        },
                                                        {
                                                            data: 'AuthorId'
                                                        },
                                                        {
                                                            data: 'ISBNNumber'
                                                        },
                                                        {
                                                            data: 'BookPrice'
                                                        },
                                                        {                                                                                                                                               
                                                            data: 'BillNo'
                                                        },
                                                        {
                                                            data: 'BillDate'
                                                        },
                                                        {
                                                            data: 'Publisher'
                                                        },
                                                        {
                                                            data: null,
                                                            orderable: false,
                                                            className: 'text-center py-0 px-1',
                                                            render: function(data, type, row, meta) {
                                                                console.log(data)
                                                                return '<button class="btn btn-sm rounded-0 py-0 delete_data btn-danger" onclick="onDelete(' + data.ISBNNumber + ')">Delete</button>';
                                                            }
                                                        }



                                                    ]
                                                });
                                            });
                                        </script>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </div>


    </div>
</div>
<script>
        function onDelete(ISBNNumber) {
    var table = $('#dataTables-example').DataTable();
    var currentPage = table.page();

    if (confirm("Are you sure you want to delete?")) {
        $.ajax({
            url: "Delete_Book.php",
            type: "POST",
            cache: false,
            data: {
                ISBNNumber: ISBNNumber
            },
            success: function(response) {
                var row = table.row($('button[onclick="onDelete(' + ISBNNumber + ')"]').parents('tr'));
                row.remove().draw();
                table.page(currentPage).draw(false);
            },
            error: function(xhr, status, error) {
                alert("Error deleting book: " + error);
            }
        });
    }
}

</script>
<?php
include "include/script.php";
?>