<?php

include "auth.php";
include "include/header.php";
include "include/sidebar.php";



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- <title>Document</title> -->

</head>

<body>
    <div id="wrapper">
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            USER DASHBOARD
                        </h1>
                    </div>


                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Laboratory Management
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12">



                                        <div class="row">
                                            <?php

                                            include 'db.php';
                                            if (!preg_match("/^[0-9]*$/", $_SESSION['SfId']) == $_SESSION['SfId']) {
                                                $sql = ("SELECT * FROM tblissuebookstudents where SfId='" . $_SESSION['SfId'] . "'");
                                            } else {
                                                $sql = ("SELECT * FROM tblissuebookdetails where SfId='" . $_SESSION['SfId'] . "'");
                                            }


                                            if ($result = mysqli_query($con, $sql)) {

                                                $rowcount = mysqli_num_rows($result);

                                                //   printf(" %d\n", );
                                            }

                                            // Close the connection
                                            mysqli_close($con);

                                            ?>


                                            <div class="row">
                                                <div class="col-md-3 col-sm-12 col-xs-12">
                                                    <div class="panel panel-primary text-center no-boder bg-color-green">
                                                        <div class="panel-left pull-left green">
                                                            <i class="fa fa-bars fa-5x"></i>

                                                        </div>
                                                        <div class="panel-right pull-right">
                                                            <h3><?php echo $rowcount  ?></h3>
                                                            <strong><a href="User_Issued_Book.php">Book Issued</a></strong>

                                                        </div>
                                                    </div>
                                                </div>
                                                <?php

                                                include 'db.php';

                                                if (!preg_match("/^[0-9]*$/", $_SESSION['SfId']) == $_SESSION['SfId']) {
                                                    $sql = ("SELECT * FROM tblissuebookstudents where SfId='" . $_SESSION['SfId'] . "' && ReturnStatus IS NULL");
                                                } else {
                                                    $sql = ("SELECT * FROM tblissuebookdetails where SfId='" . $_SESSION['SfId'] . "' && ReturnStatus > IS NULL");
                                                }
    
                                                if ($result = mysqli_query($con, $sql)) {

                                                    $rowcount = mysqli_num_rows($result);

                                                    //   printf(" %d\n", );
                                                }

                                                // Close the connection
                                                mysqli_close($con);

                                                ?>

                                                <div class="col-md-3 col-sm-12 col-xs-12">
                                                    <div class="panel panel-primary text-center no-boder bg-color-blue">
                                                        <div class="panel-left pull-left blue">
                                                            <i class="fa fa-recycle fa-5x "></i>



                                                        </div>
                                                        <div class="panel-right pull-right">
                                                            <h3><?php echo $rowcount  ?></h3>
                                                            <a href="User_Issued_Book.php"> <strong>Book Not Returned Yet</strong></a>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</body>

</html>
<?php
include "include/script.php";
?>