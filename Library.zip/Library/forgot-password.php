<?php
session_start();
error_reporting(0);
include('db.php');

if(isset($_POST['submit']))
  {
    $MobileNumber=$_POST['MobileNumber'];
    $EmailId=$_POST['EmailId'];

        $stud=mysqli_query($con,"select ID from tblstudents where  EmailId='$EmailId' and  MobileNumber ='$MobileNumber' ");
        $fecul=mysqli_query($con,"select ID from tblfaculties where  EmailId='$EmailId' and  MobileNumber ='$MobileNumber' ");
        
    $ret=mysqli_fetch_array($stud);
    $ret1=mysqli_fetch_array($fecul);
    if($ret>0){
      $_SESSION['MobileNumber']=$MobileNumber;
      $_SESSION['EmailId']=$EmailId;
     header('location:reset-password.php');
    }elseif($ret1>0){
      $_SESSION['MobileNumber']=$MobileNumber;
      $_SESSION['EmailId']=$EmailId;
     header('location:reset-password.php');
    }
    else{
     
      echo "<script>alert('Invalid Details. Please try again.');
      </script>";
    }
  }
  ?>




<!DOCTYPE html>
<html lang="en">
<head>
	<title>LMS Forget Password</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form p-l-55 p-r-55 p-t-178"  name="login"  method="post" id="reg">
					<span class="login100-form-title">
          LMS || Recover Password
					</span>

					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100" type="email" id="EmailId" name="EmailId" placeholder="Email Id" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input " data-validate = "Please enter password">
						<input class="input100" type="text" id="MobileNumber" name="MobileNumber" placeholder="Mobile Number" required >
						<span class="focus-input100"></span>
					</div>

					

					<div class="container-login100-form-btn p-t-50 p-b-23">
						<button class="login100-form-btn " type="submit" name="submit">
						Reset
						</button>
					</div>

					<div class="flex-col-c p-t-170 p-b-40">
						

						<a href="login.php" class="txt3">
						Login Page
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.8.0/parsley.js"></script>

    <?php
include "include/validation.php";
include "include/validation_css.php";
?>