
<?php
session_start();
error_reporting(0);
include "include/icon.php";
?>




<!DOCTYPE html>
<html lang="en">

<head>
	<title>Login V8</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->
</head>

<body>


	<div class="limiter">

		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form p-l-55 p-r-55 p-t-178" method="POST" id="reg">
					<span class="login100-form-title">
						Sign In
					</span>

					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100" type="text" id="EmailId" name="EmailId" placeholder="Email Id" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Please enter password">
						<input class="input100" type="password" id="Password" name="Password" placeholder="Password" required>
						<span class="focus-input100"></span>
					</div>

					<div class="text-right p-t-13 p-b-23">
						<span class="txt1">
							Forgot
						</span>

						<a href="forgot-password.php" class="txt2">
							Password
						</a>
					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="submit" type="submit">
							Sign in
						</button>
					</div>

					<div class="flex-col-c p-t-170 p-b-40">
						<span class="txt1 p-b-9">
							Don’t have an account?
						</span>

						<a href="Student_reg.php" class="txt3">
							Sign up now
						</a>
						<?php

						include 'db.php';


						$sql = ("SELECT * FROM admin");


						if ($result = mysqli_query($con, $sql)) {

							$rowcount = mysqli_num_rows($result);
						}


						mysqli_close($con);

						?>
						<?php
						if ($rowcount == null) {
							echo '<a href="admin/AdminRegistration.php" class="txt3"> Admin Sign Up </a>';
						}


						?>
					</div>
				</form>
			</div>
		</div>
	</div>




</body>

</html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.8.0/parsley.js"></script>

<?php
include "include/validation.php";
include "include/validation_css.php";
?>

<?php
include 'db.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require('PHPMailer/Exception.php');
require('PHPMailer/SMTP.php');
require('PHPMailer/PHPMailer.php');

if (isset($_POST["submit"])) {
	$_SESSION['last_time'] = time();


	$EmailId = mysqli_real_escape_string($con, $_POST['EmailId']);
	$SfId = mysqli_real_escape_string($con, $_POST['SfId']);
	$Password = mysqli_real_escape_string($con, $_POST['Password']);
	$Password = md5($Password);
	$mail = new PHPMailer(true);

		

try {
    
    $mail->isSMTP();                                         
    $mail->Host       = 'smtp.gmail.com';                    
    $mail->SMTPAuth   = true;                                   
    $mail->Username   = 'dubenitin445@gmail.com';                   
    $mail->Password   = 'ciruwmgrogqvedwc';                             
            
    $mail->Port       = 587;                                   

    $mail->setFrom('dubenitin445@gmail.com', 'vtcbcsr');
    $mail->addAddress("$EmailId");   

	date_default_timezone_set('Asia/Kolkata');
	$date = date('d-m-y h:i:s');
	
	
    $mail->isHTML(true);                                 
    $mail->Subject = 'library login';
    $mail->Body    = "<h3 ><span style='color:blue;'>Login Successfully</span><br><br> Login time : $date</h3>";
    
   
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

	$sql = "SELECT * FROM tblstudents WHERE EmailId = '{$EmailId}' AND Password = '{$Password}' and Status = '1'";
	$adm = "SELECT * FROM admin WHERE EmailId = '{$EmailId}' AND Password = '{$Password}'";
	$faculty = "SELECT * FROM tblfaculties WHERE EmailId = '{$EmailId}' AND Password = '{$Password}' and Status = '1'";

	$result = mysqli_query($con, $sql) or die("query failed");
	$res = mysqli_query($con, $adm) or die("query failed");
	$res2 = mysqli_query($con, $faculty) or die("query failed");

	if (mysqli_num_rows($result) > 0) {

		while ($row = mysqli_fetch_assoc($result)) {

			$_SESSION["EmailId"] = $row['EmailId'];
			$_SESSION["SfId"] = $row['SfId'];
			$_SESSION["Password"] = $row['Password'];

			$mail->send();
			header("Location: home.php");
		}
	} elseif (mysqli_num_rows($res) > 0)
		while ($row = mysqli_fetch_assoc($res)) {
			$_SESSION["EmailId"] = $row['EmailId'];
			$_SESSION["Password"] = $row['Password'];
			header("Location: admin/home.php");
		}
	elseif (mysqli_num_rows($res2) > 0)
		while ($row = mysqli_fetch_assoc($res2)) {
			$_SESSION["EmailId"] = $row['EmailId'];
			$_SESSION["SfId"] = $row['SfId'];
			$_SESSION["Password"] = $row['Password'];
			$mail->send();
			header("Location: home.php");
		}
	else {


		echo "<script>alert('EmailId or Password Not Matched ')
                    window.location.href = 'login.php';
                  </script>";
	}
}

?>