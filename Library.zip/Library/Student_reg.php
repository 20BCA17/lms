
<?php

include "include/icon.php";

include "include/validation_css.php";

?>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require('PHPMailer/Exception.php');
require('PHPMailer/SMTP.php');
require('PHPMailer/PHPMailer.php');
 if (isset($_POST["reg"])) {
    include 'db.php';
    // When form submitted, insert values into the database.

        // removes backslashes
    
        $SfId = stripslashes($_REQUEST['SfId']); 
        $SfId = mysqli_real_escape_string($con, $SfId);

        $FullName    = stripslashes($_REQUEST['FullName']);
        $FullName    = mysqli_real_escape_string($con, $FullName);

        $Status    = stripslashes($_REQUEST['Status']);
        $Status    = mysqli_real_escape_string($con, $Status);

        $EmailId = stripslashes($_REQUEST['EmailId']);
        $EmailId = mysqli_real_escape_string($con, $EmailId);

        $MobileNumber = stripslashes($_REQUEST['MobileNumber']);
        $MobileNumber = mysqli_real_escape_string($con, $MobileNumber);

        $Password = stripslashes($_REQUEST['Password']);
        $Password = mysqli_real_escape_string($con, $Password);
        
		$mail = new PHPMailer(true);

		

try {
                
    $mail->isSMTP();                                           
    $mail->Host       = 'smtp.gmail.com';                    
    $mail->SMTPAuth   = true;                                  
    $mail->Username   = 'dubenitin445@gmail.com';                   
    $mail->Password   = 'ciruwmgrogqvedwc';                             
   
    $mail->Port       = 587;                        

    //Recipients
    $mail->setFrom('dubenitin445@gmail.com', 'To Nitin');
    $mail->addAddress("$EmailId");     //Add a recipient
  

    $mail->isHTML(true);                                  
    $mail->Subject = 'VTCBCSR Library Registration';
    $mail->Body    = "<h3 style='color:blue;'>Registration Successfully</h3>
    <table border=2  style='width: 300px;margin: auto; padding: 8px; margin-bottom: 10px;'>
    <thead>
    <tr>
        <th>UserName </th>
        <td>$EmailId</td>
    </tr>
</thead>
<tbody>
    <tr>
        <th>Password</th>
        <td>$Password</td>
    </tr>
</tbody>
</table><br>
<p>Thank You for Registration</p>
<br>
Login Vtcbcsr Library &nbsp;<a href='login.php' style='text-decoration:none;color:blue; '>Click here</a>";
    // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

        if(!preg_match ("/^[0-9]*$/",$SfId)==$SfId){
            $query    = "INSERT into `tblstudents` (SfId  ,FullName,Status, EmailId, MobileNumber , Password)
            VALUES ('$SfId','$FullName','$Status',  '$EmailId', '$MobileNumber', '" . md5($Password) . "')";
        }
        else{
            $query    = "INSERT into `tblfaculties` (SfId  ,FullName,Status, EmailId, MobileNumber , Password)
            VALUES ('$SfId','$FullName','$Status',  '$EmailId', '$MobileNumber', '" . md5($Password) . "')";
        }
       
             
        $result   = mysqli_query($con, $query);
        if ($result) {
            
            header("Location:reg_msg.php");
        } else {
            echo "failed";
        }


    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login V8</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form p-l-55 p-r-55 p-t-178" method="POST" action="<?php $_SERVER['PHP_SELF']; ?>" id="reg">
					<span class="login100-form-title">
						Sign Up
					</span>

					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100" type="text"  placeholder="Student Id / Faculty Id" name="SfId" id="myInput" required>
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100" type="text" name="FullName" placeholder="SURNAME FRISTNAME LASTNAME" required>
						<input type="hidden" class="form-control"  name="Status" value="1" />
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100" type="text"  name="EmailId" id="email_address"  required placeholder="Enter Email ID" data-parsley-type="email" data-parsley-trigger="focusout" data-parsley-checkemail data-parsley-checkemail-message="Email Address already Exists" >
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100 input_text" type="text" name="MobileNumber" data-minlength="10" maxlength="10" id="mobile" data-parsley-minlength="10" data-parsley-minlength-message="minlength 10 number" data-parsley-type="digits" data-parsley-type-message="only numbers" placeholder="Phone Number" required>
						<span class="focus-input100"></span>
					</div>
				

					<div class="wrap-input100 validate-input m-b-16" data-validate = "Please enter password">
						<input class="input100" type="password" name="Password" id="password" placeholder="Password" required data-parsley-length="[4, 6]" data-parsley-trigger="keyup">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-50" data-validate = "Please enter password">
						<input class="input100" type="password" id="confirm_password" placeholder="Confirm Password" data-parsley-equalto="#password" data-parsley-trigger="keyup" required class="form-control">
						<span class="focus-input100"></span>
					</div>
					
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" type="submit" name="reg">
						Register
						</button>
					</div>

					<div class="flex-col-c p-t-170 p-b-40">
						<span class="txt1 p-b-9">
							Login
						</span>

						<a href="login.php" class="txt3">
							Sign in
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
	
	


</body>
</html>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.8.0/parsley.js"></script>

    <?php
include "include/validation.php";
include "include/validation.php";

?>