<!DOCTYPE html>
<html lang="en">

<head>
  <title>LMS Reset Password</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="css/util.css">
  <link rel="stylesheet" type="text/css" href="css/main.css">
  <!--===============================================================================================-->
</head>

<body>

  <div class="limiter">
    <div class="container-login100">
      <div class="wrap-login100">
        <form class="login100-form validate-form p-l-55 p-r-55 p-t-178" id="reg" name="resetpassword" onSubmit="return checkpass();" method="post">
          <span class="login100-form-title">
            Reset Password
          </span>

          <div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
            <input class="input100" type="password" id="newpassword" name="newpassword" placeholder="New Password" data-parsley-trigger="keyup">
            <span class="focus-input100"></span>
          </div>

          <div class="wrap-input100 validate-input" data-validate="Please enter password">
            <input class="input100" type="password" id="confirmpassword" name="confirmpassword" placeholder="confirmpassword" required data-parsley-equalto="#newpassword" data-parsley-trigger="keyup">
            <span class="focus-input100"></span>
          </div>



          <div class="container-login100-form-btn  p-t-50 p-b-23">
            <button class="login100-form-btn" type="submit" name="submit">
              Reset
            </button>
          </div>

          <div class="flex-col-c p-t-170 p-b-40">
            

            <a href="forgot-password.php" class="txt3">
              Go Back
            </a>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.8.0/parsley.js"></script>

    <?php
include "include/validation.php";
include "include/validation_css.php";
?>

  <?php

  session_start();
  error_reporting(0);
  include('db.php');
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\SMTP;
  use PHPMailer\PHPMailer\Exception;
  
  require('PHPMailer/Exception.php');
  require('PHPMailer/SMTP.php');
  require('PHPMailer/PHPMailer.php');
  if (isset($_POST['submit'])) {
    $MobileNumber = $_SESSION['MobileNumber'];
    $EmailId = $_SESSION['EmailId'];
    $newpassword = md5($_POST['newpassword']);

    $mail = new PHPMailer(true);

try {
    
    $mail->isSMTP();                                         
    $mail->Host       = 'smtp.gmail.com';                    
    $mail->SMTPAuth   = true;                                   
    $mail->Username   = 'dubenitin445@gmail.com';                   
    $mail->Password   = 'ciruwmgrogqvedwc';                             
            
    $mail->Port       = 587;                                   

    $mail->setFrom('dubenitin445@gmail.com', 'vtcbcsr');
    $mail->addAddress($_SESSION["EmailId"]);   

	date_default_timezone_set('Asia/Kolkata');
	$date = date('d-m-y h:i:s');
	
	
    $mail->isHTML(true);                                 
    $mail->Subject = 'library login';
    $mail->Body    = "<h3 ><span style='color:green;'>Password Reset Successfully</h3><br>
    <table border=2 style='width: 500px; padding: 8px; margin-bottom: 10px;' >
    <thead>
       
        <tr>
            <th>New Password</th>
            <td>". $_POST['newpassword']."</td>
        </tr>
        <tr>
            <th>Date</th>
            <td>$date</td>
        </tr>
       
        
    </thead>
</table>
<br>

<p>Thank you</p>
    
    ";
    
   
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}


    $stud = "update tblstudents set Password ='$newpassword' where  EmailId='$EmailId' && MobileNumber = $MobileNumber ";
    $facul = "update tblfaculties set Password ='$newpassword' where  EmailId='$EmailId' && MobileNumber = $MobileNumber ";
    // $row=mysqli_fetch_array($query);
    $result = mysqli_query($con, $stud);
    $result = mysqli_query($con, $facul);
    if ($result) {
      $mail->send();
      echo "<script>alert('Password successfully changed');
window.location.href = 'logout.php';</script>";
    }
    else{
      echo "<script>alert('Please Try Again');
      window.location.href = 'reset-password.php';</script>";
    }

  }
  ?>
  
