<?php
session_start();
// session_destroy();
if(empty(($_SESSION['EmailId'])||($_SESSION['SfId']) )){
    header("Location:login.php");
}

if(isset($_SESSION["EmailId"]))
{
 if((time() - $_SESSION['last_time']) > 900) // Time in Seconds
 {

 header("location:logout.php");
 }
 else
 {
 $_SESSION['last_time'] = time();

 }
}
else
{
 header('Location:login.php');
}
?>
