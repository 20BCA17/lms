<?php
include "auth.php";
include "include/header.php";
include "include/sidebar.php";
?>
<html>

<head>
    <style>
        table,
        th,
        td {
            border: 1px solid black;
            border-collapse: collapse;
        }
    </style>
</head>

<body>
    <div id="wrapper">
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Issued Book
                        </h1>
                    </div>


                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Issued Books
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12">
                                        <?php require "db.php"; ?>
                                        <?php
                                        if (!preg_match("/^[0-9]*$/", $_SESSION['SfId']) == $_SESSION['SfId']) {

                                            $data = mysqli_query($con, "SELECT * from tblissuebookstudents where SfId= '" . $_SESSION['SfId'] . "'");
                                        } else {
                                            $data = mysqli_query($con, "SELECT * from tblissuebookdetails where SfId= '" . $_SESSION['SfId'] . "'");
                                        }

                                        $num=1;
                                        ?>


                                        <div class="table-responsive">
                                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                                <thead>
                                                    <tr class="dark">
                                                        <th>Id</th>
                                                        <th>BookName</th>
                                                        <th>Accession Number</th>
                                                        <th>Issued Date</th>
                                                        <th>Return Date</th>
                                                        <th>Penalty</th>



                                                    </tr>
                                                </thead>
                                                <?php foreach ($data as $value) { ?>
                                                    <tr>
                                                        
                                                        <td><?php echo $num ?></td>
                                                        <td><?php $Bookname = "SELECT * FROM `tblissuebookstore` WHERE BookId='".$value['BookId']."'";
                                                                    $run3 = mysqli_query($con, $Bookname);
                                                                    while ($row3 = mysqli_fetch_assoc($run3)) {
                                                                        $BookName = $row3['BookName'];
                                                                        echo $BookName;
                                                                    } ?></td>
                                                        <td><?php echo $value['BookId']; ?></td>
                                                        <td><?php echo $value['IssuesDate']; ?></td>
                                                        <td><?php if ($value['ReturnStatus'] == "") {
                                                                echo '<span style="color:red";>Not Return Yet</span>';

                                                            } 
                                                            elseif($value['ReturnStatus'] >= 0){
                                                                echo $value['ReturnDate'];
                                                            }
                                                            else {
                                                                echo '<span style="color:red";>Not Return Yet</span>';
                                                            }  ?></td>
                                                        <td><?php echo $value['ReturnStatus']; ?></td>


                                                    </tr>

                                                <?php $num++;} ?>
                                            </table>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html>

<?php
include "include/script.php";
?>