
<html>

<head>
	<!-- <link rel="stylesheet" type="text/css" href="bootstrap.css"> -->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<body>




<div class="limiter">

<div class="container-login100">
	<div class="wrap-login100">
		<form class="login100-form validate-form p-l-55 p-r-55 p-t-178" action="<?php $_SERVER['PHP_SELF'];?>" method="post" id="reg">
			<span class="login100-form-title">
			Change Password
			</span>

			<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
				<input class="input100" type="password" id="EmailId" name="Password" placeholder="Current password" required >
				<span class="focus-input100"></span>
			</div>
			<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
				<input class="input100" type="password" id="EmailId" name="newpassword" placeholder="New password" required data-parsley-length="[8, 16]" data-parsley-trigger="keyup" >
				<span class="focus-input100"></span>
			</div>
			<div class="wrap-input100 validate-input m-b-30" data-validate="Please enter username">
				<input class="input100" type="password" id="EmailId" name="confpassword" placeholder="confirm password" required data-parsley-equalto="#password" data-parsley-trigger="keyup">
				<span class="focus-input100"></span>
			</div>
			<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="submit" type="submit">
						Update
						</button>
					</div>
			

					<div class="flex-col-c p-t-170 p-b-40">
						<span class="txt1 p-b-9">

						</span>

						
					</div>

			
		</form>
	</div>
</div>
</div>
	

	</div>
	

	</div>

</body>

</html>

<?php
    
		include 'db.php';
		use PHPMailer\PHPMailer\PHPMailer;

use PHPMailer\PHPMailer\Exception;

require('PHPMailer/Exception.php');
require('PHPMailer/SMTP.php');
require('PHPMailer/PHPMailer.php');

		if (isset($_POST["submit"])) {	
			session_start();
			$c = mysqli_real_escape_string($con, $_POST['Password']);
			$newpassword = mysqli_real_escape_string($con, $_POST['newpassword']);
			// $oldpass = md5($c);
			// echo ($oldpass); die;
// Set the new timezone
date_default_timezone_set('Asia/Kolkata');
$date = date('d-m-y h:i:s');

			$mail = new PHPMailer(true);

			try {
								 
				$mail->isSMTP();                                           
				$mail->Host       = 'smtp.gmail.com';                   
				$mail->SMTPAuth   = true;                                  
				$mail->Username   = 'dubenitin445@gmail.com';                    
				$mail->Password   = 'ciruwmgrogqvedwc';                              
			   
				$mail->Port       = 587;                                   
		
			   
				$mail->setFrom('dubenitin445@gmail.com', 'vtcbcsr');
				$mail->addAddress($_SESSION["EmailId"]);     
		
		
				
			} catch (Exception $e) {
				echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
			}

			if ($_SESSION['Password'] == md5($c)) {
				
				$sql1 = "UPDATE tblstudents SET Password='" . md5($newpassword)  . "' WHERE EmailId='" . $_SESSION["EmailId"] . "'";
				$sql2 = "UPDATE tblfaculties SET Password='" . md5($newpassword)  . "' WHERE EmailId='" . $_SESSION["EmailId"] . "'";
				$sql3 = "UPDATE admin SET Password='" . md5($newpassword)  . "' WHERE EmailId='" . $_SESSION["EmailId"] . "'";
				// echo $sql1; die;
				mysqli_query($con, $sql1);
				mysqli_query($con, $sql2);
				mysqli_query($con, $sql3);
				mysqli_close($con);
				
				$mail->isHTML(true);                                
            $mail->Subject = 'Change Password';
            $mail->Body    = "<h3 style='color:green';>Successfully Change Password</h3><br>
            <table border=2 style='width: 500px; padding: 8px; margin-bottom: 10px;' >
            <thead>
                
                <tr>
                    <th>old password</th>
                    <td>".$_POST['Password']."</td>
                </tr>
                <tr>
                    <th>currunt password</th>
                    <td>". $_POST['newpassword']."</td>
                </tr>
                <tr>
                    <th>Date</th>
                    <td>$date</td>
                </tr>
               
                
            </thead>
        </table>
        <br>
        
        <p>Thank you</p>";
		$mail->send();
				echo "<script>alert('Password Has been Updated ')
								window.location.href = 'logout.php';
							  </script>";
							
			} else {
				echo "<script>alert('Input Correct Password');</script>";
			}
		}

		?>